%+------------------------------------------------------------------------+
%| Matlab script to extract SST anomalies for 1 km reef pixels from the   |
%| 5 km datasets.                                                         |
%| Adele Dixon - last updated 16/09/2021                                  |
%+------------------------------------------------------------------------+

%+------------------------------------------------------------------------+
%| Read in reef pixels.                                                   |
%+------------------------------------------------------------------------+

reef_coords = csvread('observed/japan/xy_coords_japan.csv');
reef_coords(:,2:3) = round(reef_coords(:,2:3),2);

lat = reef_coords(:,2);
lon = reef_coords(:,3);

%+------------------------------------------------------------------------+
%| Read in SST data filenames.                                            |
%+------------------------------------------------------------------------+

files = dir('SST/CCI_anom/SST_*.nc');
%files = dir('SST/CoralTemp_anom/SST_*.nc');

%+------------------------------------------------------------------------+
%| Set time range to extract data for. Extract data in batches of 1000    |
%| days.                                                                  |
%+------------------------------------------------------------------------+

t1 = 1:1000:11688;
t2 = 1000:1000:11000; 
t2 = [t2 11688];

r = str2double(getenv('SGE_TASK_ID'));

t1 = t1(r);
t2 = t2(r);

files = files(t1:t2);

%+------------------------------------------------------------------------+
%| Set the number of files.                                               |
%+------------------------------------------------------------------------+

nfiles = length(files);

%+------------------------------------------------------------------------+
%| Read the variables lat and lon from the netCDF file.                   |
%+------------------------------------------------------------------------+

netCDF_lon = ncread(strcat('SST/CCI_anom/',files(1).name),'lon');
netCDF_lat = ncread(strcat('SST/CCI_anom/',files(1).name),'lat');
%netCDF_lon = ncread(strcat('SST/CoralTemp_anom/',files(1).name),'lon');
%netCDF_lat = ncread(strcat('SST/CoralTemp_anom/',files(1).name),'lat');

%+------------------------------------------------------------------------+
%| Find the regional boundary.                                            |
%+------------------------------------------------------------------------+

min_lat = min(lat);
max_lat = max(lat);

min_lon = min(lon);
max_lon = max(lon);

%+------------------------------------------------------------------------+
%| Extract region from 5 km grid.                                         |
%+------------------------------------------------------------------------+

netCDF_lat_range = find(netCDF_lat > min_lat - 0.1 &...
    netCDF_lat < max_lat + 0.1);
netCDF_lon_range = find(netCDF_lon > min_lon - 0.1 &...
    netCDF_lon < max_lon + 0.1);

netCDF_lat_region = netCDF_lat(netCDF_lat_range);
netCDF_lon_region = netCDF_lon(netCDF_lon_range);

%+------------------------------------------------------------------------+
%| Create 1 km grid.                                                      |
%+------------------------------------------------------------------------+

[X,Y] = meshgrid(min(netCDF_lat_region):0.005:max(netCDF_lat_region), ...
    min(netCDF_lon_region):0.005:max(netCDF_lon_region));

%+------------------------------------------------------------------------+
%| Find indices of reef pixels in 1 km grid.                              |
%+------------------------------------------------------------------------+

lat_1km = X(1,:);
lon_1km = Y(:,1);

lat_1km = round(lat_1km,3);
lon_1km = round(lon_1km,3);

idx_lat = zeros(length(lat),1);
idx_lon = zeros(length(lon),1);

for i = 1:length(lat)
   idx_lat(i) = find(lat(i) == lat_1km); 
   idx_lon(i) = find(lon(i) == lon_1km); 
end

%+------------------------------------------------------------------------+
%| Interpolate 5 km SST to 1 km grid.                                     |
%+------------------------------------------------------------------------+

reef_sst = zeros(length(lat),nfiles);

for k = 1:nfiles
    % Set filepath.
    filepath = strcat('SST/CCI_anom/',files(k).name);
    %filepath = strcat('SST/CoralTemp_anom/',files(k).name);
    % Read in SST anomaly.
    sst = ncread(filepath,'anom',[1 1],[inf inf],[1 1]);
    % Fll missing data points longitudinally by linear interpolation.
    sst = fillmissing(sst,'linear',1);
    % Extract SST range for study region.
    sst = sst(netCDF_lon_range,:);
    sst = sst(:,netCDF_lat_range);
    % Interpolate 5 km SST anomaly to 1 km SST anomaly by bilinear
    % interpolation.
    interp_sst = griddata(netCDF_lat_region,netCDF_lon_region,sst,X,Y);
    % Extract SST anomaly for 1 km coordinates.
    for i = 1:length(lat)
       reef_sst(i,k) = interp_sst(idx_lon(i),idx_lat(i)); 
    end
    disp(k)
end

%+------------------------------------------------------------------------+
%| Write SST data to file.                                                |
%+------------------------------------------------------------------------+

t = t1:t2;

data = [reef_coords reef_sst];
t = [nan(1,3) t];
data = [t;data];

csvwrite(strcat('observed/japan/sst_cci_anomaly',num2str(r),'.csv'),data)
%csvwrite(strcat('observed/japan/sst_coraltemp_anomaly',...
%num2str(r),'.csv'),data)

quit;
