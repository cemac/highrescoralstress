function [t] = f_leap_years(pivotyr,time) 
% MATLAB function to convert days since 0000-01-01 to dates but
% excluding leap years.
% Code is required for CMIP5 models with 'no leap' calendars e.g. CCSM4.

% Written by Kelly Kearney
% Kearney, K. 2013. datevec with no leap year time series. [Online].
% [Accessed 10 April 2018]. Available from:
% https://uk.mathworks.com/matlabcentral/answers/81453-datevec-with-no-
% leap-year-timeseries.
% 20/04/2018 - Adapted by Adele Dixon

% Input:
% time    - time (days since 0000-01-01)
% pivotyr - year that day count begins (0000)

% Output:
% t       - time (dates excluding leap years)

% Identify leap years.

nyr = max(time./365);
yrs = pivotyr:(pivotyr + nyr);
isleap = @(x) (mod(x,4)==0 & mod(x,100)~=0) | mod(x,400) == 0;
leapyrs = yrs(isleap(yrs));

% Calculate date numbers

dayofyear = rem(time, 365);
yr = floor(time/365) + pivotyr;
t = datenum(pivotyr, 1, 1) + time;
for i = 1:length(leapyrs)
  needsbump = yr > leapyrs(i) | (yr == leapyrs(i) & dayofyear > 59);
  t(needsbump) = t(needsbump) + 1;
end

% Convert time to yyyy-mm-dd format. 

t_datenum = t + datenum(pivotyr);
t = datevec(t_datenum);

end