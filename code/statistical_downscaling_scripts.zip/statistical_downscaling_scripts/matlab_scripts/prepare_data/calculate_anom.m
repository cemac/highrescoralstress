%+------------------------------------------------------------------------+
%| Matlab script to calculate 5 km SST anomalies by subtracting the       |
%| monthly climatology for the period overlapping with MUR SST.           |
%| Adele Dixon - last updated 04/01/2021                                  |
%+------------------------------------------------------------------------+

%+------------------------------------------------------------------------+
%| Read in filenames.                                                     |
%+------------------------------------------------------------------------+

files = dir('SST/CCI/*/*/*/*CDR2.1-v02.0-fv01.0.nc');
%files = dir('SST/CoralTemp/*/coraltemp_v1.0*');

%+------------------------------------------------------------------------+
%| Set time.                                                              |
%+------------------------------------------------------------------------+

t1 = datetime(1985,01,01);

% For CCI
t2 = datetime(2016,12,31);

% For CoralTemp
%t2 = datetime(2019,12,31);

t = t1:t2;
t = t';

%+------------------------------------------------------------------------+
%| Set filepaths.                                                         |
%+------------------------------------------------------------------------+

[y,m,d] = ymd(t);

% DAYS

d_string = cell(length(t),1);
for i = 1:length(t)
   if d(i) < 10
       d_string{i} = strcat(num2str(0),num2str(d(i)));
   else
       d_string{i} = num2str(d(i));
   end
end

% MONTHS

m_string = cell(length(t),1);
for i = 1:length(t)
   if m(i) < 10
       m_string{i} = strcat(num2str(0),num2str(m(i)));
   else
       m_string{i} = num2str(m(i));
   end
end

%+------------------------------------------------------------------------+
%| Read in latitude and longitude.                                        |
%+------------------------------------------------------------------------+

i = 1;
filename = strcat('SST/CCI/',num2str(y(i)),'/',m_string(i),...
    '/',d_string(i),'/',files(i).name);
%filename = strcat('SST/CoralTemp/',num2str(y(i)),'/',files(i).name);

lon = ncread(filename,'lon');
lat = ncread(filename,'lat');

%+------------------------------------------------------------------------+
%| Extract files for month j.                                             |
%| - 12 tasks run simultaneously for 1 - 12 months.                       |
%+------------------------------------------------------------------------+

j = str2double(getenv('SGE_TASK_ID'));

idx = m == j;

files = files(idx);
m_string = m_string(idx);
d_string = d_string(idx);
y = y(idx);

%+------------------------------------------------------------------------+
%| Read in SST files for month j.                                         |
%+------------------------------------------------------------------------+

sst = zeros(length(lon),length(lat),length(files));

for i = 1:length(files)
    filename = strcat('SST/CCI/',num2str(y(i)),'/',m_string(i),...
        '/',d_string(i),'/',files(i).name);
    %filename = strcat('SST/CoralTemp/',num2str(y(i)),'/',files(i).name);
    sst(:,:,i) = ncread(filename, 'analysed_sst');
end

%+------------------------------------------------------------------------+
%| Calculate monthly climatology                                          |
%| (Feb 2006 - Dec 2016).                                                 |
%+------------------------------------------------------------------------+

t3 = datetime(2006,02,01);
start_t = find(ismember(t,t3));

t4 = datetime(2016,12,31);
end_t = find(ismember(t,t4));

clim = nanmean(sst(:,:,start_t:end_t),3);

%+------------------------------------------------------------------------+
%| Write monthly climatology to netCDF file.                              |
%+------------------------------------------------------------------------+

output_filename = strcat('SST/CCI_monthly_clim_',num2str(j),'.nc');
%output_filename = strcat('SST/CoralTemp_monthly_clim_',num2str(j),'.nc');

nccreate(output_filename,'lat','Dimensions',...
    {'latitude',length(lat)},'Format','netcdf4','DeflateLevel',9)
nccreate(output_filename,'lon','Dimensions',...
    {'longitude',length(lon)},'Format','netcdf4','DeflateLevel',9)
nccreate(output_filename,'clim','Dimensions',...
    {'longitude',length(lon),'latitude',length(lat)},...
    'Format','netcdf4','DeflateLevel',9) 
ncwrite(output_filename,'lat',lat);
ncwrite(output_filename,'lon',lon);
ncwrite(output_filename,'clim',clim);

%+------------------------------------------------------------------------+
%| Calculate anomaly and write to file.                                   |
%+------------------------------------------------------------------------+

for i = 1:length(files)
    % Calculate SST anomalies.
    anom = sst(:,:,i) - clim;
    % Write to file.
    output_filename = strcat('SST/CCI_anom/SST_',num2str(y(i)),...
        '_',m_string(i),'_',d_string(i),'.nc');
    %output_filename = strcat('SST/CoralTemp_anom/',files(i).name);
    nccreate(output_filename,'lat','Dimensions',...
        {'latitude',length(lat)},'Format','netcdf4','DeflateLevel',9)
    nccreate(output_filename,'lon','Dimensions',...
        {'longitude',length(lon)},'Format','netcdf4','DeflateLevel',9)
    nccreate(output_filename,'anom','Dimensions',...
        {'longitude',length(lon),'latitude',length(lat)},...
        'Format','netcdf4','DeflateLevel',9) 
    ncwrite(output_filename,'lat',lat);
    ncwrite(output_filename,'lon',lon);
    ncwrite(output_filename,'anom',anom);
end

quit;
