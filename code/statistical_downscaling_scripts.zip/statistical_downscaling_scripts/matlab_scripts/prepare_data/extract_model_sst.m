%+------------------------------------------------------------------------+
%| Matlab script to extract model SST for 1 km pixels.                    |
%| Adele Dixon - last updated 05/01/2022                                  |
%+------------------------------------------------------------------------+

%+------------------------------------------------------------------------+
%| Read in model names.                                                   |
%+------------------------------------------------------------------------+

model_name = {'ACCESS-CM2','ACCESS-ESM1-5','BCC-CSM2-MR','GFDL-CM4',...
    'MRI-ESM2-0','NorESM2-LM','NorESM2-MM','CanESM5','CESM2-WACCM',...
    'CMCC-CM2-SR5','EC-Earth3','EC-Earth3-Veg','IPSL-CM6A-LR',...
    'MPI-ESM1-2-HR','NESM3'};

%+------------------------------------------------------------------------+
%| Select model to extract.                                               |
%+------------------------------------------------------------------------+

model_name = model_name{1};

%+------------------------------------------------------------------------+
%| Run the model scenarios as separate tasks.                             |
%+------------------------------------------------------------------------+

r = str2double(getenv('SGE_TASK_ID'));

if isequal(model_name,'GFDL-CM4') 
    
if r == 1
    file = strcat('CMIP6/tos/historical/tos_Oday_',model_name,'.nc');
elseif r == 2
    file = strcat('CMIP6/tos/ssp245/tos_Oday_',model_name,'.nc');
elseif r == 3
    file = strcat('CMIP6/tos/ssp585/tos_Oday_',model_name,'.nc');
end

elseif isequal(model_name,'NESM3') 
    
if r == 1
    file = strcat('CMIP6/tos/historical/tos_Oday_',model_name,'.nc');
elseif r == 2
    file = strcat('CMIP6/tos/ssp126/tos_Oday_',model_name,'.nc');
elseif r == 3
    file = strcat('CMIP6/tos/ssp245/tos_Oday_',model_name,'.nc');
elseif r == 4
    file = strcat('CMIP6/tos/ssp585/tos_Oday_',model_name,'.nc');
end
    
else

if r == 1
    file = strcat('CMIP6/tos/historical/tos_Oday_',model_name,'.nc');
elseif r == 2
    file = strcat('CMIP6/tos/ssp126/tos_Oday_',model_name,'.nc');
elseif r == 3
    file = strcat('CMIP6/tos/ssp245/tos_Oday_',model_name,'.nc');
elseif r == 4
    file = strcat('CMIP6/tos/ssp370/tos_Oday_',model_name,'.nc');
elseif r == 5
    file = strcat('CMIP6/tos/ssp585/tos_Oday_',model_name,'.nc');
end

end

%+------------------------------------------------------------------------+
%| Read in time.                                                          |
%+------------------------------------------------------------------------+

t = ncread(file,'time');

%+------------------------------------------------------------------------+
%| Convert time from days since date to datetime.                         |
%+------------------------------------------------------------------------+

if isequal(model_name,'ACCESS-CM2') || ...
        isequal(model_name,'ACCESS-ESM1-5') || ...
        isequal(model_name,'MRI-ESM2-0') || ...
        isequal(model_name,'EC-Earth3') || ...
        isequal(model_name,'EC-Earth3-Veg') ||...
        isequal(model_name,'MPI-ESM1-2-HR')

pivotyr = '1850-01-01';
t_datenum = t + datenum(pivotyr);
t = datevec(t_datenum);

elseif isequal(model_name,'BCC-CSM2-MR') 

pivotyr = 0000;
[t] = f_leap_years(pivotyr,t);
if r == 1
    t(:,1) = t(:,1) + 1980;
else
    t(:,1) = t(:,1) + 2015;
end

elseif isequal(model_name,'GFDL-CM4') || ...
        isequal(model_name,'CanESM5') || ...
        isequal(model_name,'CMCC-CM2-SR5')

pivotyr = 0000;
[t] = f_leap_years(pivotyr,t);
t(:,1) = t(:,1) + 1850;

elseif isequal(model_name,'CESM2-WACCM')

pivotyr = 0000;
[t] = f_leap_years(pivotyr,t);
t(:,1) = t(:,1) + 0001;

elseif isequal(model_name,'NorESM2-LM') || isequal(model_name,'NorESM2-MM')

pivotyr = 0000;
[t] = f_leap_years(pivotyr,t);
t(:,1) = t(:,1) + 1800;

elseif isequal(model_name,'IPSL-CM6A-LR') 
    
if r == 1
    pivotyr = '1850-01-01';
else
    pivotyr = '2015-01-01';
end
t_datenum = t + datenum(pivotyr);
t = datevec(t_datenum);

elseif isequal(model_name,'NESM3') 

if r == 1
    pivotyr = '1850-01-01';
    t_datenum = t + datenum(pivotyr);
    t = datevec(t_datenum);
else
    pivotyr = 0000;
    [t] = f_leap_years(pivotyr,t);
    t(:,1) = t(:,1) + 2015;
end

end

t = datetime(t,'InputFormat','yyyy-MM-dd');

[y,m,d] = ymd(t);
t = [y m d];
t = datetime(t);

%+------------------------------------------------------------------------+
%| Find start and end time.                                               |
%+------------------------------------------------------------------------+

if r == 1
    if isequal(model_name,'CESM2-WACCM')
        start_d = datetime(1985,01,01);
        end_d = datetime(2015,01,01);
    else
        start_d = datetime(1985,01,01);
        end_d = datetime(2014,12,31);
    end
else
    if isequal(model_name,'CESM2-WACCM')
        start_d = datetime(2015,01,02);
        end_d = datetime(2100,12,31);
    else
        start_d = datetime(2015,01,01);
        end_d = datetime(2100,12,31);
    end
end

start_d_idx = ind2sub(size(t),find(t == start_d));
end_d_idx = ind2sub(size(t),find(t == end_d));

t = t(start_d_idx:end_d_idx);

%+------------------------------------------------------------------------+
%| Read in the latitude and longitude from the model file.                |
%+------------------------------------------------------------------------+

if isequal(model_name,'GFDL-CM4') || isequal(model_name,'CESM2-WACCM')
    netCDF_lat = ncread(file,'lat'); 
    netCDF_lon = ncread(file,'lon');
elseif isequal(model_name,'IPSL-CM6A-LR')
    netCDF_lat = ncread(file,'nav_lat'); 
    netCDF_lon = ncread(file,'nav_lon');
else
    netCDF_lat = ncread(file,'latitude'); 
    netCDF_lon = ncread(file,'longitude');
end

%+------------------------------------------------------------------------+
%| Convert from single to double.                                         |
%+------------------------------------------------------------------------+

if isequal(model_name,'GFDL-CM4') || isequal(model_name,'IPSL-CM6A-LR')
    netCDF_lat = double(netCDF_lat);
    netCDF_lon = double(netCDF_lon);
end

%+------------------------------------------------------------------------+
%| Convert lon to 0-360.                                                  |
%+------------------------------------------------------------------------+

netCDF_lon_idx = netCDF_lon < 0;
netCDF_lon(netCDF_lon_idx) = netCDF_lon(netCDF_lon_idx) + 360;

%+------------------------------------------------------------------------+
%| Read in study region coordinates.                                      |
%+------------------------------------------------------------------------+

coords = csvread('observed/japan/xy_coords_japan.csv');

%+------------------------------------------------------------------------+
%| Convert latitude and longitude from -180-180 to 0-360.                 |
%+------------------------------------------------------------------------+

coords_idx = coords(:,2) < 0;
coords(coords_idx,2) = coords(coords_idx,2) + 360;

coords(:,2:3) = round(coords(:,2:3),2);

%+------------------------------------------------------------------------+
%| Find coordinates in study region boundary.                             |
%+------------------------------------------------------------------------+

min_lat = min(coords(:,2));
max_lat = max(coords(:,2));
min_lon = min(coords(:,3));
max_lon = max(coords(:,3));

[temp_lon_i,temp_lat_j] = find(netCDF_lon > (min_lon-1) & ...
    netCDF_lon < (max_lon+1) & netCDF_lat > (min_lat-1) & ...
    netCDF_lat < (max_lat+1));
    
temp_start = [min(temp_lon_i), min(temp_lat_j),start_d_idx];

temp_range = [max(temp_lon_i)-min(temp_lon_i)+1, ...
        max(temp_lat_j)-min(temp_lat_j)+1,1];

%+------------------------------------------------------------------------+
%| Extract netCDF_lat and netCDF_lon for tos range.                       |
%+------------------------------------------------------------------------+

netCDF_lat = netCDF_lat(temp_start(1):temp_start(1)+temp_range(1)-1,...
    temp_start(2):temp_start(2)+temp_range(2)-1);
netCDF_lon = netCDF_lon(temp_start(1):temp_start(1)+temp_range(1)-1,...
    temp_start(2):temp_start(2)+temp_range(2)-1);

%+------------------------------------------------------------------------+
%| Flip latitude left to right (MPI-ESM1-2-HR only).                      |
%+------------------------------------------------------------------------+

if isequal(model_name,'MPI-ESM1-2-HR')
    netCDF_lat = fliplr(netCDF_lat);
    netCDF_lon = fliplr(netCDF_lon);
end

%+------------------------------------------------------------------------+
%| Round to 1 km resolution.                                              |
%+------------------------------------------------------------------------+

netCDF_lon = round(netCDF_lon,2);
netCDF_lat = round(netCDF_lat,2);

%+------------------------------------------------------------------------+
%| Interpolate model grid to 0.01 degree grid per reef pixel.             |
%+------------------------------------------------------------------------+

[X,Y] = meshgrid(min(netCDF_lat,[],'all'):0.01:max(netCDF_lat,[],'all'), ...
    min(netCDF_lon,[],'all'):0.01:max(netCDF_lon,[],'all'));

%+------------------------------------------------------------------------+
%| Find indices of reef pixels in 1 km grid.                              |
%+------------------------------------------------------------------------+

lat_1km = X(1,:);
lon_1km = Y(:,1);

lat_1km = round(lat_1km,2);
lon_1km = round(lon_1km,2);

idx_lat = zeros(length(coords(:,2)),1);
idx_lon = zeros(length(coords(:,3)),1);

for i = 1:length(coords(:,1))
   idx_lat(i) = find(coords(i,2) == lat_1km); 
   idx_lon(i) = find(coords(i,3) == lon_1km); 
end

%+------------------------------------------------------------------------+
%| Interpolate model SST to 1 km grid.                                    |
%+------------------------------------------------------------------------+

model_reef_sst = zeros(length(coords(:,1)),length(t));
time_step = temp_start(3);

for k = 1:length(t)
    % Read in tos. 
    tos = ncread(file, 'tos', ...
        [temp_start(1) temp_start(2) time_step],...
        temp_range, [1 1 1]);
    % Fill pixels missing data longitudinally using linear interpolation.
    tos = fillmissing(tos,'linear',1);
    % Flip tos left to right (MPI-ESM1-2-HR only).
    if isequal(model_name,'MPI-ESM1-2-HR')
        tos = fliplr(tos);
    end
    % Interpolate model SST to 1 km grid.
    interp_sst = griddata(netCDF_lat(:),netCDF_lon(:),tos(:),X,Y);
    % Extract model SST for 1 km pixels.
    for i = 1:length(coords(:,1))
       model_reef_sst(i,k) = interp_sst(idx_lon(i),idx_lat(i)); 
    end
    % Next time step.
    time_step = time_step + 1;
    disp(k)
end

disp(strcat('There are ',num2str(sum(isnan(model_reef_sst),'all'))...
    ,' NaN entries.'))

%+------------------------------------------------------------------------+
%| Adjust t and tos to be compatible with observed calendar.              |
%+------------------------------------------------------------------------+

t_full = start_d:end_d;

if length(t_full) > length(t)

dv = datevec(t_full);

filler = nan(length(coords(:,1)),1);

match = ind2sub(size(dv),find(dv(:,2) == 2 & dv(:,3) == 29));

model_reef_sst_full = cell(1,length(match));
model_reef_sst_full{1} = model_reef_sst(:,1:match(1)-1);
match = [match;length(t)+length(match)+1];

k = 2;
j = 0;
for i = 2:length(match)
   model_reef_sst_full{i} = [filler model_reef_sst(:,match(i-1)-j:match(i)-k)];
   k = k+1;
   j = j+1;
end

model_reef_sst = cell2mat(model_reef_sst_full);

model_reef_sst = fillmissing(model_reef_sst,'linear',2);

end

%+------------------------------------------------------------------------+
%| Write model SST data to file.                                          |
%+------------------------------------------------------------------------+

% Set output filepath.

if isequal(model_name,'GFDL-CM4') 
    
if r == 1
    output_filename = strcat(model_name,'/historical/sst_japan.nc');
elseif r == 2
    output_filename = strcat(model_name,'/ssp245/sst_japan.nc');
elseif r == 3
    output_filename = strcat(model_name,'/ssp585/sst_japan.nc');
end

elseif isequal(model_name,'NESM3')
    
if r == 1
    output_filename = strcat(model_name,'/historical/sst_japan.nc');
elseif r == 2
    output_filename = strcat(model_name,'/ssp126/sst_japan.nc');
elseif r == 3
    output_filename = strcat(model_name,'/ssp245/sst_japan.nc');
elseif r == 4
    output_filename = strcat(model_name,'/ssp585/sst_japan.nc');
end
    
else
    
if r == 1
    output_filename = strcat(model_name,'/historical/sst_japan.nc');
elseif r == 2
    output_filename = strcat(model_name,'/ssp126/sst_japan.nc');
elseif r == 3
    output_filename = strcat(model_name,'/ssp245/sst_japan.nc');
elseif r == 4
    output_filename = strcat(model_name,'/ssp370/sst_japan.nc');
elseif r == 5
    output_filename = strcat(model_name,'/ssp585/sst_japan.nc');
end
    
end

% Create netCDF variables.

coords_idx = coords(:,2) > 180;
coords(coords_idx,2) = coords(coords_idx,2) - 360;

id = coords(:,1);
lat = coords(:,2);
lon = coords(:,3);

t1 = datetime(1985,01,01);
t2 = datetime(2100,12,31);
t = t1:t2;
t_days = 0:length(t)-1;

if r == 1
    t3 = datetime(2014,12,31);
    end_t = find(ismember(t,t3));
    t_days = t_days(1:end_t);
else
    t3 = datetime(2015,01,01);
    start_t = find(ismember(t,t3));
    t_days = t_days(start_t:end);
end

% Set variables: 1. FID, 2. lat, 3. lon, 4. time, 5. sst

nccreate(output_filename,'id','Dimensions',...
    {'id',length(id)},'Format','netcdf4','DeflateLevel',9)

nccreate(output_filename,'lat','Dimensions',...
    {'latitude',length(lat)},'Format','netcdf4','DeflateLevel',9)
ncwriteatt(output_filename, 'lat', 'units', 'decimal degrees');
    
nccreate(output_filename,'lon','Dimensions',...
    {'longitude',length(lon)},'Format','netcdf4','DeflateLevel',9)
ncwriteatt(output_filename, 'lon', 'units', 'decimal degrees');

nccreate(output_filename,'time','Dimensions',...
    {'time',length(t_days)},'Format','netcdf4','DeflateLevel',9)
ncwriteatt(output_filename, 'time', 'units', 'days since 1985-01-01');
    
nccreate(output_filename,'sst','Dimensions',...
    {'id',length(id),'time',length(t_days)},...
    'Format','netcdf4','DeflateLevel',9) 
ncwriteatt(output_filename, 'sst', 'units', 'degree Celsius');

% Write variables

ncwrite(output_filename,'id',id);
ncwrite(output_filename,'time',t_days);
ncwrite(output_filename,'lat',lat);
ncwrite(output_filename,'lon',lon);
ncwrite(output_filename,'sst',model_reef_sst);

quit;
