function [t] = f_day2serial_360day(day,pivotyr,pivotmonth,startyear,...
    startmonth,noIntperday)
% Matlab function to convert days since pivot year for a 360 day calendar 
% to dates.
% Function ignores Feb 29 and 30 (making these dates NaN) 

% Written by Keith Roberts, School of Marine and Atmospheric Science, 2014
% Roberts, K. 2014. Convert 360 day calendar days to serial date. 
% Version 1.1. [Online]. [Accessed 11 April 2018]. Available from:
% https://uk.mathworks.com/matlabcentral/fileexchange/47869-day2serial-
% 360day
% 11/04/2018 - Adapted by Adele Dixon

% Determine if particular year is leap year (1) or not (0).
isleap = @(x) (mod(x,4)==0 & mod(x,100)~=0) | mod(x,400) == 0; 

% Model output is saved with a time scale of "days since
% YYYY-12-01 00:00:00", where every year has 360 days.  This function
% converts those dates into a serial date number.
%
% Input:
%
% day         - number of days since pivot year (this is your time 
%               variable you want to convert).
% pivotyr     - pivot year, i.e. year that day count begins (1859)
% pivotmonth  - pivot month, i.e. month that day count begins (12)
% startyr     - year that the time series starts on 
% startmonth  - month that the time series begins 
% noIntperday - no. of intervals per day, i.e 6 hourly data = 4 

% dn          - datenum in serial date format for the corresponding 
%               gregorian calendar days. 

% Output:
% t - time (dates)

% This corrects for the difference in calendars (model compared to 
% gregorian) up to the start year

% Number of days since 0 time origin in model world
dn_cal = datenum(pivotyr, pivotmonth, 1) + day; 

% Actual number of days since 0 time origin
dn_greg=datenum(startyear,startmonth,1); 

% Difference in number of days between model world and actual
start_off=dn_greg-dn_cal(1); 
% This is the number of days in the model world corresponding to a 365 day 
% calendar since 0 time origin
dn=dn_cal+start_off; 

% Loop through dn. When datestr returns a 30, 31 (depending on month) or 
% is Feb. and either 28 or 29, add one to the dn vector to skip to the 1st 
% of the next month.

% THIRTY DAY HATH SEPTEMBER (9), APRIL (4), JUNE (6) AND NOVEMBER (11). 
% ALL THE REST HAVE THIRTY-ONE, EXCEPT THE MONTH OF FEB.

for idn=1:length(dn)

    if isnan(dn(idn)) == 1 
        % Do nothing and skip. 
    
    elseif str2num(datestr(dn(idn,1),'dd'))==31  && str2num(datestr(dn...
            (idn,1),'HH'))==0
        % If 31-day month and just hit day 31, skip dn one value to the 
        % next month making the 31st day of that month actually the first 
        % day of the next month.
        dn(idn:end,1)=dn(idn:end,1) + 1;
        % 'Skipped day 31'.
        idn;
        
    elseif str2num(datestr(dn(idn,1),'mm'))==2  %if datestr is in feb.
       leapstatus= isleap(str2num(datestr(dn(idn,1),'yyyy')));
        if leapstatus== 1 && str2num(datestr(dn(idn,1),'dd'))==29 && ...
                str2num(datestr(dn(idn,1),'HH'))==0
            % Since there is no feb. 30 during a leap year, the next time
            % in the next day must be NaN and one must be subtracted 
            % from the dn row after the NaNs.
            dn(idn+noIntperday:idn+(2*noIntperday),1)=NaN;
            % Starting right after the NaNs, subtract one from all
            % datenumbers 
            dn(idn+(2*noIntperday)+1:end,1)=dn(idn+(2*noIntperday)+...
                1:end,1)-1;
            % 'Skipped feb 29'.
            
        elseif leapstatus== 0 && str2num(datestr(dn(idn,1),'dd'))==28 ...
                && str2num(datestr(dn(idn,1),'HH'))==0
            % Since there is no feb. 29 and feb 30 during a non-leap year, 
            % the next two days must be NaN to correspond with the 
            % gregorian calendar and two must be subtracted from the dn 
            % row after the NaNs.
            dn(idn+noIntperday:idn+(3*noIntperday),1)=NaN;  
            % NaN everthing from one day ahead of current time to 3 days 
            % ahead of current time starting after NaNs remove 2 days from 
            % datenumber to bring it back to March 1st.
            dn(idn+(3*noIntperday)+1:end,1)=dn(idn+(3*noIntperday)+...
                1:end,1)-2;
            %' Skipped march 1st and 2nd'.
        else
            % None of the criteria are met. 
            % Leave date alone.
            
        end
    end
    
% Convert serial datetime to dates.
    
t = datevec(dn);
    
end