%+------------------------------------------------------------------------+
%| Matlab script to downscale CoralTemp to MUR using change factor and    |
%| combine the datasets in a single time series.                          |
%| Adele Dixon - last updated 11/02/2022                                  |
%+------------------------------------------------------------------------+

%+------------------------------------------------------------------------+
%| Read in CoralTemp SST anomaly data.                                    |
%+------------------------------------------------------------------------+

files = dir('observed/japan/sst_ct_anomaly*');
files = struct2cell(files);
files = files(1:1,1:length(files(1,:)));
files = natsortfiles(files);
files = files';

sst_ct = cell(1,length(files));
for i = 1:length(files)
    data = csvread(strcat('observed/japan/',files{i}));
    sst_ct{i} = data(2:end,4:end);
end

sst_ct = cell2mat(sst_ct);

%+------------------------------------------------------------------------+
%| Read in CCI SST anomaly data.                                          |
%+------------------------------------------------------------------------+

files = dir('observed/japan/sst_cci_anomaly*');
files = struct2cell(files);
files = files(1:1,1:length(files(1,:)));
files = natsortfiles(files);
files = files';

sst_cci = cell(1,length(files));
for i = 1:length(files)
    data = csvread(strcat('observed/japan/',files{i}));
    sst_cci{i} = data(2:end,4:end);
end

sst_cci = cell2mat(sst_cci);

%+------------------------------------------------------------------------+
%| Read in MUR SST data.                                                  |
%+------------------------------------------------------------------------+

filepath = 'observed/japan/sst_mur_japan.csv';

sst_mursst = csvread(filepath);
coords = sst_mursst(2:end,1:3);
sst_mursst = sst_mursst(2:end,4:end);

%+------------------------------------------------------------------------+
%| Check for pixels missing SST data for MUR.                             |
%+------------------------------------------------------------------------+

check = isnan(sst_mursst(:,1));

if sum(check(:,1)) > 0
    disp(['There are ',num2str(sum(check(:,1))),...
        ' NaN entries in the MUR SST Analysis dataset.'])
else
    disp('There are no NaN entries in the MUR SST Analysis dataset')
end

%+------------------------------------------------------------------------+
%| Isolate MUR time period that overlaps with CCI (02/2006-12/2016).      |
%+------------------------------------------------------------------------+

t1 = datetime(2003,01,01);
t2 = datetime(2019,12,31);
t = t1:t2;

[y,m,d] = ymd(t);
t = [y;m;d];

t_start = find(t(1,:) == 2006 & t(2,:) == 2 & t(3,:) == 1);
t_end = find(t(1,:) == 2016 & t(2,:) == 12 & t(3,:) == 31);
t = t(:,t_start:t_end);

%+------------------------------------------------------------------------+
%| Extract MUR SST from 01/02/2006 - 31/12/2016.                          |
%+------------------------------------------------------------------------+

sst_mursst_clim = sst_mursst(:,t_start:t_end);

%+------------------------------------------------------------------------+
%| Extract the MUR SST data for the time period to be used in the single  | 
%| time series 01/02/2006 - 31/12/2019. Note that data prior to 02/2006   |
%| are discarded.                                                         |
%+------------------------------------------------------------------------+

sst_mursst = sst_mursst(:,t_start:end);

%+------------------------------------------------------------------------+
%| Calculate monthly mean SST climatology for MUR (02/2006-12/2016).      |
%+------------------------------------------------------------------------+

m = t(2,:);

month_mn_clim_mursst = zeros(length(sst_mursst_clim(:,1)),max(m));

for i = 1:max(m)
    month_mn_clim_mursst(:,i) = mean(sst_mursst_clim(:,(m==i)),2);
end

%+------------------------------------------------------------------------+
%| Add the monthly mean climatology to CoralTemp anomaly daily data.      |
%+------------------------------------------------------------------------+

t1 = datetime(1985,01,01);
t2 = datetime(2019,12,31);
t = t1:t2;

[y,m,d] = ymd(t);
t = [y;m;d];

bias_corrected_ct = zeros(size(sst_cci));

for i = 1:max(m)
    bias_corrected_ct(:,m==i) = sst_ct(:,m==i) + month_mn_clim_mursst(:,i);
end

%+------------------------------------------------------------------------+
%| Add the monthly mean climatology to CCI anomaly daily data.            |
%+------------------------------------------------------------------------+

t1 = datetime(1985,01,01);
t2 = datetime(2016,12,31);
t = t1:t2;

[y,m,d] = ymd(t);
t = [y;m;d];

bias_corrected_cci = zeros(size(sst_cci));

for i = 1:max(m)
    bias_corrected_cci(:,m==i) = sst_cci(:,m==i) + month_mn_clim_mursst(:,i);
end

%+------------------------------------------------------------------------+
%| Extract CCI period overlapping with MUR (02/2006-12/2016).             |
%+------------------------------------------------------------------------+

t_start = find(t(1,:) == 2006 & t(2,:) == 2 & t(3,:) == 1);

bias_corrected_cci_overlap = bias_corrected_cci(:,t_start:end);

%+------------------------------------------------------------------------+
%| Calculate monthly mean SST for overlapping period.                     |
%+------------------------------------------------------------------------+

t = t(:,t_start:end);

[my,~,my_idx] = unique(t(1:2,:)','rows','stable');
my_idx = my_idx';

month_mn_cci = zeros(length(bias_corrected_cci_overlap(:,1)),max(my_idx));
month_mn_mur = zeros(length(sst_mursst_clim(:,1)),max(my_idx));

for i = 1:max(my_idx)
    month_mn_cci(:,i) = mean(bias_corrected_cci_overlap(:,(my_idx==i)),2);
    month_mn_mur(:,i) = mean(sst_mursst_clim(:,(my_idx==i)),2);
end

%+------------------------------------------------------------------------+
%| Bias correct MUR to CCI.                                               |
%+------------------------------------------------------------------------+

eqn = zeros(length(coords(:,1)),2);
mon = length(my(:,1));
sst_mur_adjusted = zeros(length(coords(:,1)),length(sst_mursst(1,:)));

for k = 1:length(coords(:,1))
    X = [ones(mon,1) month_mn_mur(k,:)'];
    eqn(k,:) = X\month_mn_cci(k,:)'; 
    sst_mur_adjusted(k,:) = (sst_mursst(k,:)*eqn(k,2))+eqn(k,1);
end

%+------------------------------------------------------------------------+
%| Extract CCI period overlapping with CoralTemp (01/1985-12/2016).       |
%+------------------------------------------------------------------------+

t_end = find(t(1,:) == 2016 & t(2,:) == 12 & t(3,:) == 31);

bias_corrected_ct_overlap = bias_corrected_ct(:,1:t_end);

%+------------------------------------------------------------------------+
%| Calculate monthly mean SST for overlapping period.                     |
%+------------------------------------------------------------------------+

t = t(:,1:t_end);

[my,~,my_idx] = unique(t(1:2,:)','rows','stable');
my_idx = my_idx';

month_mn_cci = zeros(length(bias_corrected_cci(:,1)),max(my_idx));
month_mn_ct = zeros(length(bias_corrected_ct_overlap(:,1)),max(my_idx));

for i = 1:max(my_idx)
    month_mn_cci(:,i) = mean(bias_corrected_cci(:,(my_idx==i)),2);
    month_mn_ct(:,i) = mean(bias_corrected_ct_overlap(:,(my_idx==i)),2);
end

%+------------------------------------------------------------------------+
%| Bias correct CoralTemp to CCI.                                         |
%+------------------------------------------------------------------------+

eqn = zeros(length(coords(:,1)),2);
mon = length(my(:,1));
sst_ct_adjusted = zeros(length(coords(:,1)),length(bias_corrected_ct(1,:)));

for k = 1:length(coords(:,1))
    X = [ones(mon,1) month_mn_ct(k,:)'];
    eqn(k,:) = X\month_mn_cci(k,:)'; 
    sst_ct_adjusted(k,:) = (bias_corrected_ct(k,:)*eqn(k,2))+eqn(k,1);
end

%+------------------------------------------------------------------------+
%| Keep CoralTemp SST to 28/02/2006.                                      |
%+------------------------------------------------------------------------+

t1 = datetime(1985,01,01);
t2 = datetime(2019,12,31);
t = t1:t2;
t3 = datetime(2006,02,28);
end_t = find(ismember(t,t3));

sst_ct_adjusted = sst_ct_adjusted(:,1:end_t);

%+------------------------------------------------------------------------+
%| Extract CoralTemp SST February 2006.                                   |
%+------------------------------------------------------------------------+

t = t(1:end_t);
t3 = datetime(2006,02,01);
t_start = find(ismember(t,t3));

feb_2006_ct = sst_ct_adjusted(:,t_start:end);

%+------------------------------------------------------------------------+
%| Extract MUR SST February 2006 (first 28 days).                         |
%+------------------------------------------------------------------------+

feb_2006_mur = sst_mur_adjusted(:,1:28);

%+------------------------------------------------------------------------+
%| Blend CoralTemp and MUR in Feb 2006.                                   |
%+------------------------------------------------------------------------+

k1 = 0:27;
k2 = fliplr(k1);

blended_sst = zeros(length(coords(:,1)),length(k1));

for i = 1:length(k1)
    blended_sst(:,i) = (k2(i)/27) * feb_2006_ct(:,i) +...
        (k1(i)/27) * feb_2006_mur(:,i);
end

%+------------------------------------------------------------------------+
%| Combine CoralTemp and MUR into single time series.                     |
%+------------------------------------------------------------------------+

obs_sst = [sst_ct_adjusted(:,1:t_start-1) blended_sst ...
    sst_mur_adjusted(:,29:end)];

%+------------------------------------------------------------------------+
%| Set time in days since 01/01/1985.                                     |
%+------------------------------------------------------------------------+

t1 = datetime(1985,01,01);
t2 = datetime(2019,12,31);
t = t1:t2;
t_days = 0:length(t)-1;

%+------------------------------------------------------------------------+
%| Set output filename.                                                   |
%+------------------------------------------------------------------------+

output_filename = 'observed/japan/sst_1km_japan_coraltemp.nc';

%+------------------------------------------------------------------------+
%| Set variables: 1. ID, 2. lat, 3. lon, 4. time, 5. sst                  |
%+------------------------------------------------------------------------+

id = coords(:,1);

nccreate(output_filename,'id','Dimensions',...
    {'id',length(id)},'Format','netcdf4','DeflateLevel',9)

lat = coords(:,2);

nccreate(output_filename,'lat','Dimensions',...
    {'latitude',length(lat)},'Format','netcdf4','DeflateLevel',9)
ncwriteatt(output_filename, 'lat', 'units', 'decimal degrees');

lon = coords(:,3);
    
nccreate(output_filename,'lon','Dimensions',...
    {'longitude',length(lon)},'Format','netcdf4','DeflateLevel',9)
ncwriteatt(output_filename, 'lon', 'units', 'decimal degrees');

nccreate(output_filename,'time','Dimensions',...
    {'time',length(t_days)},'Format','netcdf4','DeflateLevel',9)
ncwriteatt(output_filename, 'time', 'units', 'days since 1985-01-01');
    
nccreate(output_filename,'sst','Dimensions',...
    {'id',length(id),'time',length(t_days)},...
    'Format','netcdf4','DeflateLevel',9) 
ncwriteatt(output_filename, 'sst', 'units', 'degree Celsius');

%+------------------------------------------------------------------------+
%| Write variables.                                                       |
%+------------------------------------------------------------------------+

ncwrite(output_filename,'id',id);
ncwrite(output_filename,'time',t_days);
ncwrite(output_filename,'lat',lat);
ncwrite(output_filename,'lon',lon);
ncwrite(output_filename,'sst',obs_sst);

c = now;
c = datetime(c,'ConvertFrom','datenum');
c = string(c);

ncwriteatt(output_filename, '/', 'Conventions', 'CF-1.8');
ncwriteatt(output_filename, '/', 'title', 'HighResCoralStress');
ncwriteatt(output_filename, '/', 'Version', '1.1');
ncwriteatt(output_filename, '/', 'institution', 'University of Leeds');
ncwriteatt(output_filename, '/', 'history', strcat(c,'; The seasonal periods for the downscaling models have been changed.'));
ncwriteatt(output_filename, '/', 'Dataset_citation', 'Dixon, A.M., Forster, P.M., Heron, S.F., Stoner, A.M.K., Beger, M. 2022. Future loss of local-scale thermal refugia in coral reef ecosystems. PLOS Clim 1(2): e0000004.');
ncwriteatt(output_filename, '/', 'Region', 'Japan');
ncwriteatt(output_filename, '/', 'source', '1. MUR SST Analysis; 2. ESA CCI SST Analysis; 3. NOAA CRW CoralTemp SST');
ncwriteatt(output_filename, '/', 'references', ['JPL MUR MEaSUREs Project. GHRSST Level 4 MUR Global Foundation Sea Surface Temperature Analysis. Ver. 4.1. PO.DAAC, CA, USA. 2015 [cited 25 Jan 2019]. Available: http://dx.doi.org/10.5067/GHGMR-4FJ04' newline ...
    'Merchant CJ, Embury O, Roberts-Jones J, Fiedler EK, Bulgin CE, Corlett GK, et al. ESA Sea Surface Temperature Climate Change Initiative (ESA SST CCI): Analysis long term product version 1.1. In: Centre for Environmental Data Analysis [Internet]. 2016. Available: http://dx.doi.org/10.5285/2262690A-B588-4704-B459-39E05527B59A' newline ...
    'NOAA Coral Reef Watch. NOAA Coral Reef Watch Version 3.1 Daily Global 5-km Satellite Coral Bleaching Sea Surface Temperature Product. 2018 [cited 16 Apr 2018]. Available: https://coralreefwatch.noaa.gov/product/5km/index.php']);

quit;

