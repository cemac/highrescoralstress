%+------------------------------------------------------------------------+
%| Compare the CCI section of the 1 km time series to MUR.                |
%| Adele Dixon - last updated 06/01/2022                                  |
%+------------------------------------------------------------------------+

%+------------------------------------------------------------------------+
%| Read in daily observed SST.                                            |
%+------------------------------------------------------------------------+

filename = 'observed/japan/sst_1km_japan.nc';

id = ncread(filename,'id');
lat = ncread(filename,'lat');
lon = ncread(filename,'lon');
t = ncread(filename,'time');
obs_sst = ncread(filename,'sst');

coords = [id lat lon];

%+------------------------------------------------------------------------+
%| Set dates from days since 01/01/1985.                                  |
%+------------------------------------------------------------------------+

pivotyr = '1985-01-01';
t_datenum = t + datenum(pivotyr);
t = datevec(t_datenum);

t = datetime(t,'InputFormat','yyyy-MM-dd');

[y,m,d] = ymd(t);
t = [y m d];
t = t';

%+------------------------------------------------------------------------+
%| Detrend daily SST.                                                     |
%+------------------------------------------------------------------------+

t_idx = 1:length(obs_sst(1,:));
t_idx = t_idx';

yCalc_obs = zeros(size(obs_sst));
X = [ones(length(t_idx),1) t_idx];

for k = 1:length(obs_sst(:,1))
    sst_detrend = obs_sst(k,:)';
    d = X\sst_detrend; 
    yCalc_obs(k,:) = t_idx * d(2,1);
end

obs_sst = obs_sst - yCalc_obs;

%+------------------------------------------------------------------------+
%| Calculate monthly mean.                                                |
%+------------------------------------------------------------------------+

[my,~,my_idx] = unique(t(1:2,:)','rows','stable');
my_idx = my_idx';

month_mn = zeros(length(obs_sst(:,1)),max(my_idx));

for i = 1:max(my_idx)
    month_mn(:,i) = mean(obs_sst(:,(my_idx==i)),2);
end

%+------------------------------------------------------------------------+
%| Calculate winter minimum and summer maximum SST.                       |
%+------------------------------------------------------------------------+

[~,~,y_idx] = unique(my(:,1),'rows','stable');
y_idx = y_idx';

summer_max = zeros(length(obs_sst(:,1)),max(y_idx));
winter_min = zeros(length(obs_sst(:,1)),max(y_idx));

for i = 1:max(y_idx)
    summer_max(:,i) = max(month_mn(:,(y_idx==i)),[],2);
    winter_min(:,i) = min(month_mn(:,(y_idx==i)),[],2);
end

%+------------------------------------------------------------------------+
%| Separate time series into CCI and MUR.                                 |
%+------------------------------------------------------------------------+

idx = find(my(:,1) == 2006 & my(:,2) == 2);

month_mn_cci = month_mn(:,1:idx-1);
month_mn_mur = month_mn(:,idx+1:end);

y = unique(y);

idx = find(y == 2006);

winter_min_cci = winter_min(:,1:idx-1);
winter_min_mur = winter_min(:,idx+1:end);
summer_max_cci = summer_max(:,1:idx-1);
summer_max_mur = summer_max(:,idx+1:end);

%+------------------------------------------------------------------------+
%| Calculate variability in summer max and winter min SST.                |
%+------------------------------------------------------------------------+

winter_min_var_cci = std(winter_min_cci,0,2);
winter_min_var_mur = std(winter_min_mur,0,2);
summer_max_var_cci = std(summer_max_cci,0,2);
summer_max_var_mur = std(summer_max_mur,0,2);

%+------------------------------------------------------------------------+
%| Find spectral energy for 0.5-1 year seasonal bands and 2-8 year        |
%| interannual bands.                                                     |
%| Find spectral energy for interannual and seasonal periods.             |
%| Seasonal period = 6 months to 12 months                                |
%| Interannual period = 2 years to 9 years                                |
%| Find root mean square amplitude of spectral energy.                    |
%| Langlais et al., 2017                                                  |
%+------------------------------------------------------------------------+

N_cci=length(month_mn_cci(1,:));
N_mur=length(month_mn_mur(1,:));

freq_cci = (1:N_cci/2)/(N_cci/2)*1/2*12;
freq_mur = (1:N_mur/2)/(N_mur/2)*1/2*12;

seas_cci = freq_cci < 1/0.5 & freq_cci > 1/1.1;
intera_cci = freq_cci < 1/2.5 & freq_cci > 1/9;

seas_mur = freq_mur < 1/0.5 & freq_mur > 1/1.1;
intera_mur = freq_mur < 1/2.5 & freq_mur > 1/9;

season_freq_cci = zeros(length(coords(:,1)),1);
interan_freq_cci = zeros(length(coords(:,1)),1);
season_freq_mur = zeros(length(coords(:,1)),1);
interan_freq_mur = zeros(length(coords(:,1)),1);

for i = 1:length(coords(:,1))
    y_cci = fft(month_mn_cci(i,:)-mean(month_mn_cci(i,:)))/N_cci;
    y_mur = fft(month_mn_mur(i,:)-mean(month_mn_mur(i,:)))/N_mur;
    spectra_t_cci = 2 * abs(y_cci(1:N_cci/2)).^2 ;
    spectra_t_mur = 2 * abs(y_mur(1:N_mur/2)).^2 ;
    season_freq_cci(i,:) = sum(spectra_t_cci(seas_cci));
    interan_freq_cci(i,:) = sum(spectra_t_cci(intera_cci));
    season_freq_mur(i,:) = sum(spectra_t_mur(seas_mur));
    interan_freq_mur(i,:) = sum(spectra_t_mur(intera_mur));  
end

seas_rms_cci = season_freq_cci.^(1/2);
intera_rms_cci = interan_freq_cci.^(1/2);
seas_rms_mur = season_freq_mur.^(1/2);
intera_rms_mur = interan_freq_mur.^(1/2);

%+------------------------------------------------------------------------+
%| Calculate mean and STD.                                                |
%+------------------------------------------------------------------------+

mn_cci = mean(month_mn_cci,2);
mn_mur = mean(month_mn_mur,2);
std_cci = std(month_mn_cci,0,2);
std_mur = std(month_mn_mur,0,2);

%+------------------------------------------------------------------------+
%| Write to file.                                                         |
%+------------------------------------------------------------------------+

cci = [coords mn_cci std_cci seas_rms_cci intera_rms_cci...
    winter_min_var_cci summer_max_var_cci];
mur = [coords mn_mur std_mur seas_rms_mur intera_rms_mur...
    winter_min_var_mur summer_max_var_mur];

csvwrite('observed/japan/mn_std_rms_wmv_smv_cci.csv',cci)
csvwrite('observed/japan/mn_std_rms_wmv_smv_mur.csv',mur)

%+------------------------------------------------------------------------+
%| Find difference in CCI and MUR.                                        |
%+------------------------------------------------------------------------+

sst_diff = cci(:,4:end) - mur(:,4:end);

%+------------------------------------------------------------------------+
%| Convert negative difference to positive.                               |
%+------------------------------------------------------------------------+

idx = sst_diff < 0;
sst_diff(idx) = sst_diff(idx) * -1;

%+------------------------------------------------------------------------+
%| Plot difference in sst metrics between cci and mur as boxplots.        |
%+------------------------------------------------------------------------+

figure
boxplot(sst_diff,'Whisker',10)
ylabel('Difference in SST between CCI and MUR (^{o}C)')
xticks([1 2 3 4 5 6])
xticklabels({'Mn','STD','RMS_s','RMS_i','WMV','SMV'})
hold on
x = [1 6];
y = [0.2 0.2];
plot(x,y,'r--','LineWidth',2)
hold off

savefig('compare_cci_mur.fig')

%+------------------------------------------------------------------------+
%| Identify pixels to replace with CoralTemp.                             |
%| "...winter minimum and summer maximum CCI SST variability < 0.10°C     |
%| indicating a regular climatology and a difference between CCI and MUR  |
%| in winter minimum and summer maximum SST variability > 0.10°C          |
%| indicating a difference in SST cycles between the datasets."           |
%| - Dixon et al., 2022                                                   |
%+------------------------------------------------------------------------+

idx = find(cci(:,8) < 0.1 & sst_diff(:,5) > 0.1 | ...
    cci(:,9) < 0.1 & sst_diff(:,6) > 0.1);

coords_replace = coords(idx,:);

%+------------------------------------------------------------------------+
%| Write reefs to replace.                                                |
%+------------------------------------------------------------------------+

if isempty(idx)
else
    coords_replace = [idx coords_replace];
    csvwrite('observed/japan/pixels_to_replace_with_ct.csv',coords_replace)
end



quit;
