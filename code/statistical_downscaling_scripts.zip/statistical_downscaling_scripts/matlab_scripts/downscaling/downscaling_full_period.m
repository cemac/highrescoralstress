%+------------------------------------------------------------------------+
%| Matlab script to statistically downscale SST.                          |
%| Adele Dixon - last updated 25/01/2022                                  |
%+------------------------------------------------------------------------+

%+------------------------------------------------------------------------+
%| Set model names.                                                       |
%+------------------------------------------------------------------------+

model = {'ACCESS-CM2','ACCESS-ESM1-5','BCC-CSM2-MR','CanESM5','CESM2-WACCM',...
    'CMCC-CM2-SR5','EC-Earth3','EC-Earth3-Veg','GFDL-CM4','IPSL-CM6A-LR',...
    'MPI-ESM1-2-HR','MRI-ESM2-0','NESM3','NorESM2-LM','NorESM2-MM'};

r = str2double(getenv('SGE_TASK_ID'));

%+------------------------------------------------------------------------+
%| Set SSP names.                                                         |
%+------------------------------------------------------------------------+

if r == 9
    ssp = {'ssp245','ssp585'};
elseif r == 13
    ssp = {'ssp126','ssp245','ssp585'};
else
    ssp = {'ssp126','ssp245','ssp370','ssp585'};
end

%+------------------------------------------------------------------------+
%| Read in observed SST files.                                            |
%+------------------------------------------------------------------------+    

filename = 'observed/japan/sst_1km_japan.nc';

id = ncread(filename,'id');
lon = ncread(filename,'lon');
lat = ncread(filename,'lat');
obs_t = ncread(filename,'time');
obs_sst = ncread(filename,'sst');

%+------------------------------------------------------------------------+
%| Convert days since 01/01/1985 to day month year.                       |
%+------------------------------------------------------------------------+

pivotyr = '1985-01-01';
t_datenum = obs_t + datenum(pivotyr);
obs_t = datevec(t_datenum);

obs_t = datetime(obs_t,'InputFormat','yyyy-MM-dd');

[y,m,d] = ymd(obs_t);
obs_t = [y m d];
obs_t = obs_t';

%+------------------------------------------------------------------------+
%| Read in best trend code.                                               |
%+------------------------------------------------------------------------+

best_trend = csvread(strcat(model{r},'/best_trend_code_japan.csv'));
best_trend = best_trend(:,4:end);

for ssp_no = 1:length(ssp)

%+------------------------------------------------------------------------+
%| Read in model sst.                                                     |
%+------------------------------------------------------------------------+

hist_filename = strcat(model{r},'/historical/sst_japan.nc');
proj_filename = strcat(model{r},'/',ssp{ssp_no},'/sst_japan.nc');

hist_model_sst = ncread(hist_filename,'sst');
model_sst = ncread(proj_filename,'sst');

hist_t = ncread(hist_filename,'time');
proj_t = ncread(proj_filename,'time');

%+------------------------------------------------------------------------+
%| Convert days since 01/01/1985 to day month year.                       |
%+------------------------------------------------------------------------+

% Historical

t_datenum = hist_t + datenum(pivotyr);
hist_t = datevec(t_datenum);

hist_t = datetime(hist_t,'InputFormat','yyyy-MM-dd');

[y,m,d] = ymd(hist_t);
hist_t = [y m d];
hist_t = hist_t';

% Projected

t_datenum = proj_t + datenum(pivotyr);
proj_t = datevec(t_datenum);

proj_t = datetime(proj_t,'InputFormat','yyyy-MM-dd');

[y,m,d] = ymd(proj_t);
proj_t = [y m d];
proj_t = proj_t';

model_t = [hist_t proj_t];
model_sst = [hist_model_sst model_sst];

%+------------------------------------------------------------------------+
%| Detrend observed SST.                                                  |
%+------------------------------------------------------------------------+

x_obs = 1:length(obs_t(1,:));
yCalc_obs = zeros(size(obs_sst));

for k = 1:length(obs_sst(:,1))
    if best_trend(k,ssp_no) == 1 || best_trend(k,ssp_no) == 4 ...
            || best_trend(k,ssp_no) == 5
        p = polyfit(x_obs,obs_sst(k,:),1); 
        %y = polyval(p,x_obs);
        yCalc_obs(k,:) = p(1) * x_obs;
    elseif best_trend(k,ssp_no) == 2 || best_trend(k,ssp_no) == 6
        p = polyfit(x_obs,obs_sst(k,:),2); 
        %y = polyval(p,x_obs);
        yCalc_obs(k,:) = p(1) * x_obs.^2 + p(2) * x_obs;
    elseif best_trend(k,ssp_no) == 3
        p = polyfit(x_obs,obs_sst(k,:),3); 
        %y = polyval(p,x_obs);
        yCalc_obs(k,:) = p(1) * x_obs.^3 + p(2) * x_obs.^2 + p(3) * x_obs;
    end
end

d_obs_sst = obs_sst - yCalc_obs;

%+------------------------------------------------------------------------+
%| Restructure for four 3-monthly models (e.g. Dec-Feb).                  |
%+------------------------------------------------------------------------+

month = obs_t(2,:);
months_all = 4;

past_sst = cell(1,months_all);

% Set 3 monthly periods (Dec-Jan-Feb, etc.). Note that in previous versions
% Jan-Feb-Mar, etc. were used as seasonal periods.

monthly_periods = [12 1 2; 3 4 5; 6 7 8; 9 10 11];

for i = 1:months_all
    month_idx = ind2sub(size(month),...
        find(monthly_periods(i,1) == month | ...
        monthly_periods(i,2) == month | monthly_periods(i,3) == month));
    past_sst{i} = d_obs_sst(:,month_idx);
end

%+------------------------------------------------------------------------+
%| Sort observed SST in ascending order.                                  |
%+------------------------------------------------------------------------+

for j = 1:months_all
    past_sst{j} = sort(past_sst{j},2,'ascend');
end

%+------------------------------------------------------------------------+
%| Detrend the model sst data.                                            |
%+------------------------------------------------------------------------+

x_mod = 1:length(model_t(1,:));
yCalc_mod = zeros(size(model_sst));

for k = 1:length(model_sst(:,1))
    if best_trend(k,ssp_no) == 1 
        p = polyfit(x_mod,model_sst(k,:),1); 
        %y = polyval(p,x_mod);
        yCalc_mod(k,:) = p(1) * x_mod;
    elseif best_trend(k,ssp_no) == 2 || best_trend(k,ssp_no) == 4
        p = polyfit(x_mod,model_sst(k,:),2); 
        %y = polyval(p,x_mod);
        yCalc_mod(k,:) = p(1) * x_mod.^2 + p(2) * x_mod;
    elseif best_trend(k,ssp_no) == 3 || best_trend(k,ssp_no) == 5 || ...
            best_trend(k,ssp_no) == 6
        p = polyfit(x_mod,model_sst(k,:),3); 
        %y = polyval(p,x_mod);
        yCalc_mod(k,:) = p(1) * x_mod.^3 + p(2) * x_mod.^2 + p(3) * x_mod;
    end
end

model_sst = model_sst - yCalc_mod;

%+------------------------------------------------------------------------+
%| Remove hist years from detrended model SST for training period.        |
%+------------------------------------------------------------------------+

hist_model_sst = model_sst(:,1:length(obs_t(1,:)));

%+------------------------------------------------------------------------+
%| Restructure for four 3-monthly models (e.g. Dec-Feb).                  |
%+------------------------------------------------------------------------+

past_tos = cell(1,months_all); 

for i = 1:months_all
    month_idx = ind2sub(size(month),...
        find(monthly_periods(i,1) == month |...
        monthly_periods(i,2) == month | monthly_periods(i,3) == month));
    past_tos{i} = hist_model_sst(:,month_idx);
end

%+------------------------------------------------------------------------+
%| Sort simulated SST in ascending order.                                 |
%+------------------------------------------------------------------------+

for j = 1:months_all
    past_tos{j} = sort(past_tos{j},2,'ascend');
end

%+------------------------------------------------------------------------+
%| Calculate the linear slope and intercept.                              |
%+------------------------------------------------------------------------+

eqn = cell(1,months_all);

for j = 1:months_all
    yrs = length(past_sst{j}(1,:));
    for i = 1:length(obs_sst(:,1))
        X = [ones(yrs,1) past_tos{j}(i,:)'];
        eqn{j}(i,:) = X\past_sst{j}(i,:)';   
        %yCalc2{j}(i,:) = (past_tos{j}(i,:)*eqn{j}(i,2))+eqn{j}(i,1);
    end
end

%+------------------------------------------------------------------------+
%| Restructure projections into 3-monthly periods.                        |
%+------------------------------------------------------------------------+

month2 = model_t(2,:);

proj_tos = cell(1,months_all);

for i = 1:months_all
    month_idx = ind2sub(size(month2),...
        find(monthly_periods(i,1) == month2 | ...
        monthly_periods(i,2) == month2 | monthly_periods(i,3) == month2));
    proj_tos{i} = model_sst(:,month_idx);
end

%+------------------------------------------------------------------------+
%| Statistically downscale projected SST.                                 |
%| Apply the linear models to the projections.                            |
%+------------------------------------------------------------------------+

downscale = cell(1,months_all);

for j = 1:months_all
    downscale{j} = (eqn{j}(:,2).*proj_tos{j}) + eqn{j}(:,1);
end

%+------------------------------------------------------------------------+
%| Reshape back to numerical matrix for single time series.               |
%+------------------------------------------------------------------------+

day_downscale = zeros(size(model_sst));

for i = 1:months_all
    month_idx = ind2sub(size(month2),...
        find(monthly_periods(i,1) == month2 | ...
        monthly_periods(i,2) == month2 | monthly_periods(i,3) == month2));
    for j = 1:length(month_idx)
        day_downscale(:,month_idx(j)) = downscale{i}(:,j);
    end
end

%+------------------------------------------------------------------------+
%| Add the GCM trend back in to the data.                                 |
%+------------------------------------------------------------------------+

day_downscale = day_downscale + yCalc_mod;

%+------------------------------------------------------------------------+
%| Write downscaled SST to file.                                          |
%+------------------------------------------------------------------------+

% Set output filepath.

output_filename = strcat(model{r},'/',ssp{ssp_no},...
    '/downscaled_sst_japan_1985_2100.nc');

% Set time to days since 1985-01-01.

t1 = datetime(1985,01,01);
t2 = datetime(2100,12,31);
t = t1:t2;
t_days = 0:length(t)-1;

% Create netCDF variables: 1. ID, 2. lat, 3. lon, 4. time, 5. sst

nccreate(output_filename,'id','Dimensions',...
    {'id',length(id)},'Format','netcdf4','DeflateLevel',9)

nccreate(output_filename,'lat','Dimensions',...
    {'latitude',length(lat)},'Format','netcdf4','DeflateLevel',9)
ncwriteatt(output_filename, 'lat', 'units', 'degrees_north');
ncwriteatt(output_filename, 'lat', 'axis', 'Y');
ncwriteatt(output_filename, 'lat', 'long_name', 'Latitude');
ncwriteatt(output_filename, 'lat', 'standard_name', 'latitude');

nccreate(output_filename,'lon','Dimensions',...
    {'longitude',length(lon)},'Format','netcdf4','DeflateLevel',9)
ncwriteatt(output_filename, 'lon', 'units', 'degrees_east');
ncwriteatt(output_filename, 'lon', 'axis', 'X');
ncwriteatt(output_filename, 'lon', 'long_name', 'Longitude');
ncwriteatt(output_filename, 'lon', 'standard_name', 'longitude');
  
nccreate(output_filename,'time','Dimensions',...
    {'time',length(t_days)},'Format','netcdf4','DeflateLevel',9)
ncwriteatt(output_filename, 'time', 'units', 'days since 1985-01-01');
ncwriteatt(output_filename, 'time', 'calendar', 'gregorian');
ncwriteatt(output_filename, 'time', 'axis', 'T');
ncwriteatt(output_filename, 'time', 'long_name', 'time');
ncwriteatt(output_filename, 'time', 'standard_name', 'time');

nccreate(output_filename,'sst','Dimensions',...
    {'id',length(id),'time',length(t_days)},...
    'Format','netcdf4','DeflateLevel',9,'FillValue', 9999) 
ncwriteatt(output_filename, 'sst', 'units', 'Celsius');
ncwriteatt(output_filename, 'sst', 'long_name', 'downscaled sea surface temperature');
ncwriteatt(output_filename, 'sst', 'standard_name', 'sea_surface_temperature');
ncwriteatt(output_filename, 'sst', 'missing_value', 9999);

% Write variables

ncwrite(output_filename,'id',id);
ncwrite(output_filename,'time',t_days);
ncwrite(output_filename,'lat',lat);
ncwrite(output_filename,'lon',lon);
ncwrite(output_filename,'sst',day_downscale);

%+------------------------------------------------------------------------+
%| Set model names, institution IDs and citations.                        |
%+------------------------------------------------------------------------+

model = {'ACCESS-CM2','ACCESS-ESM1-5','BCC-CSM2-MR','CanESM5','CESM2-WACCM',...
    'CMCC-CM2-SR5','EC-Earth3','EC-Earth3-Veg','GFDL-CM4','IPSL-CM6A-LR',...
    'MPI-ESM1-2-HR','MRI-ESM2-0','NESM3','NorESM2-LM','NorESM2-MM'};

institution = {'CSIRO','CSIRO','BCC','CCCma','NCAR',...
    'CMCC','EC-Earth-Consortium','EC-Earth-Consortium','NOAA-GFDL','IPSL',...
    'MPI-M','MRI','NUIST','NCC','NCC'};

citation = {'Bi D, Dix M, Marsland S, O’farrell S, Sullivan A, Bodman R, et al. Configuration and spin-up of ACCESS-CM2, the new generation Australian Community Climate and Earth System Simulator Coupled Model. J South Hemisph Earth Syst Sci. 2020;70: 225251. doi:10.1071/ES19040',...
    'Ziehn T, Chamberlain MA, Law RM, Lenton A, Bodman RW, Dix M, et al. The Australian Earth System Model: ACCESS-ESM1.5. J South Hemisph Earth Syst Sci. 2020;70: 193214. doi:10.1071/ES19035',...
    'Wu T, Lu Y, Fang Y, Xin X, Li L, Li W, et al. The Beijing Climate Center Climate System Model (BCC-CSM): The main progress from CMIP5 to CMIP6. Geosci Model Dev. 2019;12: 15731600. doi:10.5194/gmd-12-1573-2019',...
    'Swart NC, Cole JNS, Kharin V V., Lazare M, Scinocca JF, Gillett NP, et al. The Canadian Earth System Model version 5 (CanESM5.0.3). Geosci Model Dev. 2019;12: 48234873. doi:10.5194/gmd-12-4823-2019',...
    'Danabasoglu G, Lamarque JF, Bacmeister J, Bailey DA, DuVivier AK, Edwards J, et al. The Community Earth System Model Version 2 (CESM2). J Adv Model Earth Syst. 2020;12: e2019MS001916. doi:10.1029/2019MS001916',...
    'Cherchi A, Fogli PG, Lovato T, Peano D, Iovino D, Gualdi S, et al. Global Mean Climate and Main Patterns of Variability in the CMCC-CM2 Coupled Model. J Adv Model Earth Syst. 2019;11: 185209. doi:10.1029/2018MS001369',...
    'Döscher R, Acosta M, Alessandri A, Anthoni P, Arneth A, Arsouze T, et al. The EC-Earth3 Earth System Model for the Climate Model Intercomparison Project 6. Geosci Model Dev Discuss [preprint]. 2021. doi:10.5194/gmd-2020-446',...
    'Wyser K, Van Noije T, Yang S, Von Hardenberg J, O’Donnell D, Döscher R. On the increased climate sensitivity in the EC-Earth model from CMIP5 to CMIP6. Geosci Model Dev. 2020;13: 34653474. doi:10.5194/gmd-13-3465-2020',...
    'Held IM, Guo H, Adcroft A, Dunne JP, Horowitz LW, Krasting J, et al. Structure and Performance of GFDL’s CM4.0 Climate Model. J Adv Model Earth Syst. 2019;11: 36913727. doi:10.1029/2019MS001829',...
    'Boucher O, Servonnat J, Albright AL, Aumont O, Balkanski Y, Bastrikov V, et al. Presentation and Evaluation of the IPSL-CM6A-LR Climate Model. J Adv Model Earth Syst. 2020;12: e2019MS002010. doi:10.1029/2019MS002010',...
    'Müller WA, Jungclaus JH, Mauritsen T, Baehr J, Bittner M, Budich R, et al. A Higher-resolution Version of the Max Planck Institute Earth System Model (MPI-ESM1.2-HR). J Adv Model Earth Syst. 2018;10: 13831413. doi:10.1029/2017MS001217',...
    'Yukimoto S, Kawai H, Koshiro T, Oshima N, Yoshida K, Urakawa S, et al. The meteorological research institute Earth system model version 2.0, MRI-ESM2.0: Description and basic evaluation of the physical component. J Meteorol Soc Japan. 2019;97: 931965. doi:10.2151/jmsj.2019-051',...
    'Cao J, Wang B, Yang YM, Ma L, Li J, Sun B, et al. The NUIST Earth System Model (NESM) version 3: Description and preliminary evaluation. Geosci Model Dev. 2018;11: 29752993. doi:10.5194/gmd-11-2975-2018',...
    'Seland Ø, Bentsen M, Olivié D, Toniazzo T, Gjermundsen A, Graff LS, et al. Overview of the Norwegian Earth System Model (NorESM2) and key climate response of CMIP6 DECK, historical, and scenario simulations. Geosci Model Dev. 2020;13: 61656200. doi:10.5194/gmd-13-6165-2020',...
    'Seland Ø, Bentsen M, Olivié D, Toniazzo T, Gjermundsen A, Graff LS, et al. Overview of the Norwegian Earth System Model (NorESM2) and key climate response of CMIP6 DECK, historical, and scenario simulations. Geosci Model Dev. 2020;13: 61656200. doi:10.5194/gmd-13-6165-2020'};

%+------------------------------------------------------------------------+
%| Update metadata.                                                       |
%+------------------------------------------------------------------------+

c = now;
c = datetime(c,'ConvertFrom','datenum');
c = string(c);

ncwriteatt(output_filename, '/', 'Conventions', 'CF-1.8');
ncwriteatt(output_filename, '/', 'title', 'HighResCoralStress');
ncwriteatt(output_filename, '/', 'Version', '1.1');
ncwriteatt(output_filename, '/', 'institution', 'University of Leeds');
ncwriteatt(output_filename, '/', 'history', strcat(c,'; The seasonal periods for the downscaling models have been changed.'));
ncwriteatt(output_filename, '/', 'Dataset_citation', 'Dixon, A.M., Forster, P.M., Heron, S.F., Stoner, A.M.K., Beger, M. 2022. Future loss of local-scale thermal refugia in coral reef ecosystems. PLOS Clim 1(2): e0000004.');
ncwriteatt(output_filename, '/', 'Region', 'Japan');
ncwriteatt(output_filename, '/', 'source', '1. CMIP6 model tos output; 2. MUR SST Analysis; 3. ESA CCI SST Analysis; 4. NOAA CRW CoralTemp SST');
ncwriteatt(output_filename, '/', 'Model', model{r});
ncwriteatt(output_filename, '/', 'Instituion_ID', institution{r});
ncwriteatt(output_filename, '/', 'SSP', ssp{ssp_no});
ncwriteatt(output_filename, '/', 'Realisation', 'r1i1p1f1');
ncwriteatt(output_filename, '/', 'Model_described', citation{r});
ncwriteatt(output_filename, '/', 'references', ['JPL MUR MEaSUREs Project. GHRSST Level 4 MUR Global Foundation Sea Surface Temperature Analysis. Ver. 4.1. PO.DAAC, CA, USA. 2015 [cited 25 Jan 2019]. Available: http://dx.doi.org/10.5067/GHGMR-4FJ04' newline ...
    'Merchant CJ, Embury O, Roberts-Jones J, Fiedler EK, Bulgin CE, Corlett GK, et al. ESA Sea Surface Temperature Climate Change Initiative (ESA SST CCI): Analysis long term product version 1.1. In: Centre for Environmental Data Analysis [Internet]. 2016. Available: http://dx.doi.org/10.5285/2262690A-B588-4704-B459-39E05527B59A' newline ...
    'NOAA Coral Reef Watch. NOAA Coral Reef Watch Version 3.1 Daily Global 5-km Satellite Coral Bleaching Sea Surface Temperature Product. 2018 [cited 16 Apr 2018]. Available: https://coralreefwatch.noaa.gov/product/5km/index.php']);

end


quit;

