%+------------------------------------------------------------------------+
%| Matlab script to compare GCM and downscaled RMSE relative to           |
%| observations for downscaling using detrending with different order     | 
%| trends.                                                                |
%| Adele Dixon - last updated 01/07/2021                                  |
%+------------------------------------------------------------------------+

%+------------------------------------------------------------------------+
%| Set model names.                                                       |
%+------------------------------------------------------------------------+

model = {'ACCESS-CM2','ACCESS-ESM1-5','BCC-CSM2-MR','CanESM5',...
    'CESM2-WACCM','CMCC-CM2-SR5','EC-Earth3','EC-Earth3-Veg',...
    'GFDL-CM4','IPSL-CM6A-LR','MPI-ESM1-2-HR','MRI-ESM2-0','NESM3',...
    'NorESM2-LM','NorESM2-MM'};

rmse_diff_max_inc = zeros(length(model),4);
down_fail = zeros(length(model),4);

for model_no = 1:length(model)

%+------------------------------------------------------------------------+
%| Set SSPs.                                                              |
%+------------------------------------------------------------------------+
    
if model_no == 9
    ssp = {'ssp245','ssp585'};
elseif model_no == 13
    ssp = {'ssp126','ssp245','ssp585'};
else
    ssp = {'ssp126','ssp245','ssp370','ssp585'};
end

%+------------------------------------------------------------------------+
%| Set number of trend combinations and number of pixels.                 |
%+------------------------------------------------------------------------+

trends = 6;
id_no = 14895;

%+------------------------------------------------------------------------+
%| Pre-allocate matrices.                                                 |
%+------------------------------------------------------------------------+

rmse_gcm = zeros(id_no,length(ssp));
rmse_down = cell(1,length(ssp));
best_trend_code = zeros(id_no,length(ssp));
rmse_down_best = zeros(id_no,length(ssp));

for n = 1:length(ssp)

%+------------------------------------------------------------------------+
%| Read in the GCM RMSE.                                                  |
%+------------------------------------------------------------------------+

filepath1 = strcat(model{model_no},'/',ssp{n},'/japan_rmse_gcm_oddyrs.csv');    
data = csvread(filepath1);
rmse_gcm(:,n) = data(:,4);

%+------------------------------------------------------------------------+
%| Read in downscaled RMSE.                                               |
%+------------------------------------------------------------------------+

for i = 1:trends
   filepath2 = strcat(model{model_no},'/',ssp{n},'/japan_rmse_down_oddyrs_',...
       num2str(i),'.csv');   
   data = csvread(filepath2);
   rmse_down{n}(:,i) = data(:,4);
end

%+------------------------------------------------------------------------+
%| Find the trend combination with the lowest RMSE.                       |
%+------------------------------------------------------------------------+

[rmse_down_best(:,n),best_trend_code(:,n)] = min(rmse_down{n},[],2);

end

%+------------------------------------------------------------------------+
%| Write "best" trend combination to file.                                |
%+------------------------------------------------------------------------+

reef_coords = data(:,1:3);
best_trend_code_no = [reef_coords best_trend_code];

csvwrite(strcat(model{model_no},'/best_trend_code_japan.csv'),...
    best_trend_code_no)

%+------------------------------------------------------------------------+
%| Plot GCM and downscaled RMSE.                                          |
%+------------------------------------------------------------------------+

figure
for i = 1:length(ssp)
    rmse_all = [rmse_gcm(:,i) rmse_down{i} rmse_down_best(:,i)];
    if model_no == 9
        subplot(1,2,i)
    else
        subplot(2,2,i)
    end
    boxplot(rmse_all,'Whisker',100)
    ylabel('RMSE (^{o}C)')
    xticks([1 2 3 4 5 6 7 8])
    xticklabels({'GCM','1','2','3','1:2','1:3','2:3','Best'})
    title(strcat(model{model_no},':',ssp{i}))
end

%savefig(strcat(model{1},'/',ssp{n},'/RMSE_best.fig'))

%+------------------------------------------------------------------------+
%| Calculate % of reef pixels with a higher downscaled RMSE than GCM.     |
%+------------------------------------------------------------------------+

rmse_diff = rmse_gcm - rmse_down_best;
rmse_diff = round(rmse_diff,2);

idx = rmse_diff < 0;
idx = sum(idx);
down_fail_model = round((idx/length(reef_coords(:,1))) * 100,2);

if model_no == 9
    down_fail(model_no,:) = [NaN down_fail_model(1) NaN down_fail_model(2)];
elseif model_no == 13
    down_fail(model_no,:) = [down_fail_model(1) down_fail_model(2) NaN ...
        down_fail_model(3)];
else
    down_fail(model_no,:) = down_fail_model;
end

%+------------------------------------------------------------------------+
%| Calculate the maximum increase in RMSE after downscaling.              |
%+------------------------------------------------------------------------+

rmse_diff_max_inc_model = min(rmse_diff);

if model_no == 9
    rmse_diff_max_inc(model_no,:) = [NaN rmse_diff_max_inc_model(1) NaN...
        rmse_diff_max_inc_model(2)];
elseif model_no == 13
    rmse_diff_max_inc(model_no,:) = [rmse_diff_max_inc_model(1)...
        rmse_diff_max_inc_model(2) NaN rmse_diff_max_inc_model(3)];
else
    rmse_diff_max_inc(model_no,:) = rmse_diff_max_inc_model;
end

end

%+------------------------------------------------------------------------+
%| Write the percentage of reef pixels not improved by downscaling and    |
%| the increase in RMSE to file.                                          |
%+------------------------------------------------------------------------+

% Convert increases in RMSE from negative to positive.

rmse_diff_max_inc = rmse_diff_max_inc * -1;

% down_fail

model = model';
ssp126 = down_fail(:,1);
ssp245 = down_fail(:,2);
ssp370 = down_fail(:,3);
ssp585 = down_fail(:,4);

T = table(model,ssp126,ssp245,ssp370,ssp585);

writetable(T,'observed/japan/downscaling_fail_japan.csv')

% increase in rmse

ssp126 = rmse_diff_max_inc(:,1);
ssp245 = rmse_diff_max_inc(:,2);
ssp370 = rmse_diff_max_inc(:,3);
ssp585 = rmse_diff_max_inc(:,4);

T = table(model,ssp126,ssp245,ssp370,ssp585);

writetable(T,'observed/japan/increase_in_rmse_japan.csv')



