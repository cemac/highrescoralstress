%+------------------------------------------------------------------------+
%| Matlab script to statistically downscale SST for testing period.       |
%| Adele Dixon - last updated 20/01/2022                                  |
%+------------------------------------------------------------------------+

%+------------------------------------------------------------------------+
%| Set models.                                                            |
%+------------------------------------------------------------------------+

model = {'ACCESS-CM2','ACCESS-ESM1-5','BCC-CSM2-MR','CanESM5',...
    'CESM2-WACCM','CMCC-CM2-SR5','EC-Earth3','EC-Earth3-Veg',...
    'GFDL-CM4','IPSL-CM6A-LR','MPI-ESM1-2-HR','MRI-ESM2-0','NESM3',...
    'NorESM2-LM','NorESM2-MM'};

r = str2double(getenv('SGE_TASK_ID'));

%+------------------------------------------------------------------------+
%| Set SSPs.                                                              |
%+------------------------------------------------------------------------+

if r == 9
    ssp = {'ssp245','ssp585'};
elseif r == 13
    ssp = {'ssp126','ssp245','ssp585'};
else
    ssp = {'ssp126','ssp245','ssp370','ssp585'};
end

for ssp_no = 1:length(ssp)
    
%+------------------------------------------------------------------------+
%| Read in observed SST files.                                            |
%+------------------------------------------------------------------------+

filename = 'observed/japan/sst_1km_japan.nc';

id = ncread(filename,'id');
lon = ncread(filename,'lon');
lat = ncread(filename,'lat');
obs_t = ncread(filename,'time');
obs_sst = ncread(filename,'sst');

reef_coords = [id lon lat];

clearvars id lat lon

%+------------------------------------------------------------------------+
%| Convert days since 01/01/1985 to day, month, year.                     |
%+------------------------------------------------------------------------+

pivotyr = '1985-01-01';
t_datenum = obs_t + datenum(pivotyr);
obs_t = datevec(t_datenum);

obs_t = datetime(obs_t,'InputFormat','yyyy-MM-dd');

[y,m,d] = ymd(obs_t);
obs_t = [y m d];
obs_t = obs_t';

%+------------------------------------------------------------------------+
%| Remove even years from trended SST for model testing period.           |
%+------------------------------------------------------------------------+

odd_years = rem(obs_t(1,:),2);
odd_years = odd_years == 1;

obs_sst_o = obs_sst(:,odd_years);

%+------------------------------------------------------------------------+
%| Read in model sst.                                                     |
%+------------------------------------------------------------------------+

hist_filename = strcat(model{r},'/historical/sst_japan.nc');
proj_filename = strcat(model{r},'/',ssp{ssp_no},'/sst_japan1.nc');

hist_model_sst = ncread(hist_filename,'sst');
model_sst = ncread(proj_filename,'sst');

hist_t = ncread(hist_filename,'time');
proj_t = ncread(proj_filename,'time');

%+------------------------------------------------------------------------+
%| Convert days since 01/01/1985 to day, month, year.                     |
%+------------------------------------------------------------------------+

% Historical

t_datenum = hist_t + datenum(pivotyr);
hist_t = datevec(t_datenum);

hist_t = datetime(hist_t,'InputFormat','yyyy-MM-dd');

[y,m,d] = ymd(hist_t);
hist_t = [y m d];
hist_t = hist_t';

% SSP

t_datenum = proj_t + datenum(pivotyr);
proj_t = datevec(t_datenum);

proj_t = datetime(proj_t,'InputFormat','yyyy-MM-dd');

[y,m,d] = ymd(proj_t);
proj_t = [y m d];
proj_t = proj_t';

model_t = [hist_t proj_t];

%+------------------------------------------------------------------------+
%| Combine model sst in single time series.                               |
%+------------------------------------------------------------------------+

model_sst = [hist_model_sst model_sst];

%+------------------------------------------------------------------------+
%| Remove even years from trended model SST for testing period.           |
%+------------------------------------------------------------------------+

hist_model_sst = model_sst(:,1:length(obs_t(1,:)));
hist_model_sst = hist_model_sst(:,odd_years);

%+------------------------------------------------------------------------+
%| Calculate the GCM RMSE.                                                |
%+------------------------------------------------------------------------+

% Full time series.

ranked_gcm = sort(hist_model_sst,2,'ascend');
ranked_obs = sort(obs_sst_o,2,'ascend');

rmse_gcm_all = sqrt(mean(((ranked_gcm-ranked_obs).^2),2)); 

% Four 3-monthly models

month_o = obs_t(2,odd_years);
months_all = 4;

rmse_gcm_m = zeros(length(reef_coords(:,1)),months_all);

% Set 3 monthly periods (Dec-Jan-Feb, etc.). Note that in previous versions
% Jan-Feb-Mar, etc. were used as seasonal periods.

monthly_periods = [12 1 2; 3 4 5; 6 7 8; 9 10 11];

for i = 1:months_all
    month_idx = ind2sub(size(month_o),...
        find(monthly_periods(i,1) == month_o | ...
        monthly_periods(i,2) == month_o | monthly_periods(i,3) == month_o));
    ranked_obs = sort(obs_sst_o(:,month_idx),2,'ascend');
    ranked_gcm = sort(hist_model_sst(:,month_idx),2,'ascend');
    rmse_gcm_m(:,i) = sqrt(mean(((ranked_gcm-ranked_obs).^2),2)); 
end

rmse_gcm = [rmse_gcm_all rmse_gcm_m];

%+------------------------------------------------------------------------+
%| Write GCM RMSE to file.                                                |
%+------------------------------------------------------------------------+

data = [reef_coords rmse_gcm];
csvwrite(strcat(model{r},'/',ssp{ssp_no},'/japan_rmse_gcm_oddyrs.csv'),data)

%+------------------------------------------------------------------------+
%| Calculate observed and GCM mean and std (odd years).                   |
%+------------------------------------------------------------------------+

mn_obs = mean(obs_sst_o,2);
mn_gcm = mean(hist_model_sst,2);

std_obs = std(obs_sst_o,0,2);
std_gcm = std(hist_model_sst,0,2);

%+------------------------------------------------------------------------+
%| Pre-allocate matrices for storing the mean and standard deviation for  |
%| downscaled odd years.                                                  |
%+------------------------------------------------------------------------+

mn_down = zeros(length(reef_coords(:,1)),6);
std_down = zeros(length(reef_coords(:,1)),6);

%+------------------------------------------------------------------------+
%| Run downscaling six times removing a different order trend prior to    |
%| downscaling each time.                                                 |
%+------------------------------------------------------------------------+

for trend = 1:6

%+------------------------------------------------------------------------+
%| Detrend observed SST.                                                  |
%+------------------------------------------------------------------------+

if trend == 1 || trend == 4 || trend == 5

% Linear detrend:

x_obs = 1:length(obs_t(1,:));

yCalc_obs = zeros(size(obs_sst));

for k = 1:length(obs_sst(:,1))
    p = polyfit(x_obs,obs_sst(k,:),1); 
    yCalc_obs(k,:) = p(1) * x_obs;
end

elseif trend == 2 || trend == 6

% Quadratic detrend:

x_obs = 1:length(obs_t(1,:));

yCalc_obs = zeros(size(obs_sst));

for k = 1:length(obs_sst(:,1))
   p = polyfit(x_obs,obs_sst(k,:),2); 
   yCalc_obs(k,:) = p(1) * x_obs.^2 + p(2) * x_obs;
end

elseif trend == 3

% Cubic detrend.
    
x_obs = 1:length(obs_t(1,:));

yCalc_obs = zeros(size(obs_sst));

for k = 1:length(obs_sst(:,1))
   p = polyfit(x_obs,obs_sst(k,:),3); 
   yCalc_obs(k,:) = p(1) * x_obs.^3 + p(2) * x_obs.^2 + p(3) * x_obs;
end

end

obs_sst = obs_sst - yCalc_obs;

%+------------------------------------------------------------------------+
%| Select model training period. Remove odd years from detrended SST for  |
%| model training period.                                                 |
%+------------------------------------------------------------------------+

even_years = ~rem(obs_t(1,:),2);
obs_sst_e = obs_sst(:,even_years);

%+------------------------------------------------------------------------+
%| Add trend back to observed time series for next iteration.             |
%+------------------------------------------------------------------------+

obs_sst = obs_sst + yCalc_obs;

clearvars yCalc_obs

%+------------------------------------------------------------------------+
%| Restructure for four 3-monthly models (e.g. Dec-Feb).                  |
%+------------------------------------------------------------------------+

month_e = obs_t(2,even_years);

past_sst = cell(1,months_all);

for i = 1:months_all
    month_idx = ind2sub(size(month_e),...
        find(monthly_periods(i,1) == month_e | ...
        monthly_periods(i,2) == month_e | monthly_periods(i,3) == month_e));
    past_sst{i} = obs_sst_e(:,month_idx);
end

%+------------------------------------------------------------------------+
%| Sort observed SST in ascending order.                                  |
%+------------------------------------------------------------------------+

for j = 1:months_all
    past_sst{j} = sort(past_sst{j},2,'ascend');
end

%+------------------------------------------------------------------------+
%| Detrend the tos data.                                                  |
%+------------------------------------------------------------------------+

if trend == 1

% Linear detrend:

x_mod = 1:length(model_t(1,:));

yCalc_mod = zeros(size(model_sst));

for k = 1:length(model_sst(:,1))
    p = polyfit(x_mod,model_sst(k,:),1); 
    yCalc_mod(k,:) = p(1) * x_mod;
end

elseif trend == 2 || trend == 4 

% Quadratic detrend:

x_mod = 1:length(model_t(1,:));

yCalc_mod = zeros(size(model_sst));

for k = 1:length(model_sst(:,1))
   p = polyfit(x_mod,model_sst(k,:),2); 
   yCalc_mod(k,:) = p(1) * x_mod.^2 + p(2) * x_mod;
end

elseif trend == 3 || trend == 5 || trend == 6 

% Cubic detrend:

x_mod = 1:length(model_t(1,:));

yCalc_mod = zeros(size(model_sst));

for k = 1:length(model_sst(:,1))
   p = polyfit(x_mod,model_sst(k,:),3); 
   yCalc_mod(k,:) = p(1) * x_mod.^3 + p(2) * x_mod.^2 + p(3) * x_mod;
end

end

model_sst = model_sst - yCalc_mod;

%+------------------------------------------------------------------------+
%| Select the historical time series.                                     |
%+------------------------------------------------------------------------+

hist_model_sst = model_sst(:,1:length(obs_t(1,:)));

%+------------------------------------------------------------------------+
%| Add trend back to model time series for next iteration.                |
%+------------------------------------------------------------------------+

model_sst = model_sst + yCalc_mod;

%+------------------------------------------------------------------------+
%| Keep trend for historical time series.                                 |
%+------------------------------------------------------------------------+

yCalc_mod = yCalc_mod(:,1:length(obs_t(1,:)));

%+------------------------------------------------------------------------+
%| Remove odd years from detrended model SST for testing period.          |
%+------------------------------------------------------------------------+

hist_model_sst_e = hist_model_sst(:,even_years);

%+------------------------------------------------------------------------+
%| Generate 3-monthly linear models.                                      |
%+------------------------------------------------------------------------+

past_tos = cell(1,months_all); 

for i = 1:months_all
    month_idx = ind2sub(size(month_e),...
        find(monthly_periods(i,1) == month_e |...
        monthly_periods(i,2) == month_e | monthly_periods(i,3) == month_e));
    past_tos{i} = hist_model_sst_e(:,month_idx);
end

%+------------------------------------------------------------------------+
%| Sort simulated SST in ascending order.                                 |
%+------------------------------------------------------------------------+

for j = 1:months_all
    past_tos{j} = sort(past_tos{j},2,'ascend');
end

%+------------------------------------------------------------------------+
%| Calculate the linear slope and intercept.                              |
%+------------------------------------------------------------------------+

eqn = cell(1,months_all);

for j = 1:months_all
    yrs = length(past_sst{j}(1,:));
    for i = 1:length(reef_coords(:,1))
        X = [ones(yrs,1) past_tos{j}(i,:)'];
        eqn{j}(i,:) = X\past_sst{j}(i,:)';   
        %yCalc2{j}(i,:) = (past_tos{j}(i,:)*eqn{j}(i,2))+eqn{j}(i,1);
    end
end

%+------------------------------------------------------------------------+
%| Restructure projections into 3-monthly periods.                        |
%+------------------------------------------------------------------------+

month2 = obs_t(2,:);

proj_tos = cell(1,months_all);

for i = 1:months_all
    month_idx = ind2sub(size(month2),...
        find(monthly_periods(i,1) == month2 | ...
        monthly_periods(i,2) == month2 | monthly_periods(i,3) == month2));
    proj_tos{i} = hist_model_sst(:,month_idx);
end

%+------------------------------------------------------------------------+
%| Statistically downscale projected SST.                                 |
%| Apply the linear models to the projections.                            |
%+------------------------------------------------------------------------+

downscale = cell(1,months_all);

for j = 1:months_all
    downscale{j} = (eqn{j}(:,2).*proj_tos{j}) + eqn{j}(:,1);
end

%+------------------------------------------------------------------------+
%| Reshape back to numerical matrix for single time series.               |
%+------------------------------------------------------------------------+

day_downscale = zeros(size(hist_model_sst));

for i = 1:months_all
    month_idx = ind2sub(size(month2),...
        find(monthly_periods(i,1) == month2 | ...
        monthly_periods(i,2) == month2 | monthly_periods(i,3) == month2));
    for j = 1:length(month_idx)
        day_downscale(:,month_idx(j)) = downscale{i}(:,j);
    end
end

%+------------------------------------------------------------------------+
%| Add the GCM trend back in to the data.                                 |
%+------------------------------------------------------------------------+

day_downscale = day_downscale + yCalc_mod;

%+------------------------------------------------------------------------+
%| Split downscaled data into odd years.                                  |
%+------------------------------------------------------------------------+

day_downscale = day_downscale(:,odd_years);

%+------------------------------------------------------------------------+
%| Calculate mean and std.                                                |
%+------------------------------------------------------------------------+

mn_down(:,trend) = mean(day_downscale,2);
std_down(:,trend) = std(day_downscale,0,2);

%+------------------------------------------------------------------------+
%| Calculate RMSE for downscaled data.                                    |
%+------------------------------------------------------------------------+

% Full time series.

ranked_obs = sort(obs_sst_o,2,'ascend');
ranked_down = sort(day_downscale,2,'ascend');

rmse_down_all = sqrt(mean(((ranked_down-ranked_obs).^2),2)); 

% Four 3-monthly models

rmse_down_m = zeros(length(reef_coords(:,1)),months_all);

for i = 1:months_all
    month_idx = ind2sub(size(month_o),...
        find(monthly_periods(i,1) == month_o | ...
        monthly_periods(i,2) == month_o | monthly_periods(i,3) == month_o));
    ranked_obs = sort(obs_sst_o(:,month_idx),2,'ascend');
    ranked_down = sort(day_downscale(:,month_idx),2,'ascend');
    rmse_down_m(:,i) = sqrt(mean(((ranked_down-ranked_obs).^2),2)); 
end

rmse_down = [rmse_down_all rmse_down_m];

%+------------------------------------------------------------------------+
%| Write stats to file.                                                   |
%+------------------------------------------------------------------------+

% Downscaled RMSE

data = [reef_coords rmse_down];
csvwrite(strcat(model{r},'/',ssp{ssp_no},'/japan_rmse_down_oddyrs_',...
    num2str(trend),'.csv'),data)

end

% Mean and std

data = [reef_coords mn_obs mn_gcm mn_down std_obs std_gcm std_down];
csvwrite(strcat(model{r},'/',ssp{ssp_no},'/japan_mn_std_odd_yrs.csv'),data)

end

quit;

