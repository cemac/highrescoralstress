%+------------------------------------------------------------------------+
%| Matlab script to calculate observed degree heating weeks (DHW) and     |
%| thermal stress metrics.                                                |
%| Adele Dixon - last updated 01/06/2022                                  |
%+------------------------------------------------------------------------+

%+------------------------------------------------------------------------+
%| Read in observed SST.                                                  |
%+------------------------------------------------------------------------+

filepath = 'observed/japan/sst_1km_japan.nc';

id = ncread(filename,'id');
lat = ncread(filepath,'lat');
lon = ncread(filepath,'lon');
t = ncread(filepath,'time');
sst = ncread(filepath,'sst');

idx_nan = isnan(sst(:,1));

%+------------------------------------------------------------------------+
%| Convert days since 01/01/1985 to year, month, day.                     |
%+------------------------------------------------------------------------+

pivotyr = '1985-01-01';
t_datenum = t + datenum(pivotyr);
t = datevec(t_datenum);

t = datetime(t,'InputFormat','yyyy-MM-dd');

[y,m,d] = ymd(t);
t = [y m d];
t = t';

%+------------------------------------------------------------------------+
%| Calculate annual mean SST.                                             |
%+------------------------------------------------------------------------+

[~,~,y_idx] = unique(t(1,:)','rows','stable');
y_idx = y_idx';

ann_mn = zeros(length(lat),max(y_idx));
for i = 1:max(y_idx)
    ann_mn(:,i) = mean(sst(:,(y_idx==i)),2);
end

%+------------------------------------------------------------------------+
%| Find trend and p-value for feasible generalised least squares.         |
%+------------------------------------------------------------------------+

all_years = unique(t(1,:));

fgls_slope = zeros(length(lat),1);
fgls_p = zeros(length(lat),1);

n = length(all_years) - 2;

for i = 1:length(lat)
    if isnan(ann_mn(i,1))
        fgls_slope(i,j) = NaN;
        fgls_p(i,j) = NaN;
    else
    % Find slope and p-value for generalised least squares
        [coeff,se] = fgls(all_years',ann_mn(i,:)','arLags',1);
        fgls_slope(i,:) = coeff(2);
        t2 = coeff(2)/se(2);
        fgls_p(i,:) = 2*tcdf(-abs(t2),n);
    end
end

%+------------------------------------------------------------------------+
%| Write trend in annual mean sst.                                        |
%+------------------------------------------------------------------------+

filepath = 'observed/trend_ann_mn_sst_japan.csv';

data = [id lon lat fgls_slope fgls_p];

csvwrite(filepath,data)

%+------------------------------------------------------------------------+
%| Calculate monthly mean SST.                                            |
%+------------------------------------------------------------------------+

[my,~,my_idx] = unique(t(1:2,:)','rows','stable');
my_idx = my_idx';

month_mn = zeros(length(lat),max(my_idx));
for i = 1:max(my_idx)
    month_mn(:,i) = mean(sst(:,(my_idx==i)),2);
end

%+------------------------------------------------------------------------+
%| Find spectral energy for 0.5-1 year seasonal bands and 3-8 year        |
%| inte-rannual bands.                                                    |
%| Seasonal period = 6 months to 12 months                                |
%| Interannual period = 3 years to 8 years                                |
%| Find root mean square amplitude of spectral energy.                    |
%| Langlais et al. (2017)                                                 |
%+------------------------------------------------------------------------+

N=length(month_mn(1,:));
freq=(1:N/2)/(N/2)*1/2*12;

seas = freq < 1/0.5 & freq > 1/1;
intera = freq < 1/3 & freq > 1/8;

season_freq = zeros(length(lat),1);
interan_freq = zeros(length(lat),1);

for i = 1:length(lat)
    y = fft(month_mn(i,:)-mean(month_mn(i,:)))/N;
    spectra_t = 2 * abs(y(1:N/2)).^2 ;
    season_freq(i,:) = sum(spectra_t(seas));
    interan_freq(i,:) = sum(spectra_t(intera));  
end

seas_rms = season_freq.^(1/2);
intera_rms = interan_freq.^(1/2);

%+------------------------------------------------------------------------+
%| Write trend in annual mean sst.                                        |
%+------------------------------------------------------------------------+

filepath = 'observed/seas_int_sst_var_japan.csv';

data = [id lon lat seas_rms intera_rms];

csvwrite(filepath,data)

%+------------------------------------------------------------------------+
%| Calculate degree heating weeks (DHW). Method by NOAA Coral Reef Watch  |
%| https://coralreefwatch.noaa.gov/product/5km/methodology.php#dhw        |
%+------------------------------------------------------------------------+
%+------------------------------------------------------------------------+
%| Find maximum monthly mean (MMM) period (1985-2012).                    |
%+------------------------------------------------------------------------+
    
mmm_idx = my(:,1) >= 1985 & my(:,1) <= 2012;
m_idx = my(mmm_idx,2);

mmm_idx = mmm_idx';
month_mn_base = month_mn(:,mmm_idx);

yr = 1985:2012;

%+------------------------------------------------------------------------+
%| Regress monthly mean (MM) 1985-2012.                                   |
%+------------------------------------------------------------------------+

mm = zeros(length(lat),max(m_idx));

for i = 1:length(lat)
    for k = 1:max(m_idx)
        p = polyfit(yr,month_mn_base(i,m_idx==k),1);
        mm(i,k) = p(1)*1988.2857 + p(2);
    end
end

%+------------------------------------------------------------------------+
%| Find MMM.                                                              |
%+------------------------------------------------------------------------+

mmm = max(mm,[],2);

%+------------------------------------------------------------------------+
%| Calculate hotspots.                                                    |
%+------------------------------------------------------------------------+

sst_anom = sst - mmm;

clearvars sst

%+------------------------------------------------------------------------+
%| Calculate DHWs (> 1 degC).                                             |
%+------------------------------------------------------------------------+

sst_anom(sst_anom < 1) = 0;

d = t(3,84:end);
d_idx = 1:length(d);

dhw = zeros(length(lat),length(d));
for i = 1:length(lat)
    k = 84;
    for j = 1:max(d_idx)
         dhw(i,j) = sum(sst_anom(i,k-83:k)/7);
         k = k+1;
    end
end

clearvars sst_anom

%+------------------------------------------------------------------------+
%| Calculate oberved probability of bleaching > 4DHW for 1985-2019.       |
%+------------------------------------------------------------------------+

t = t(:,84:end);

dhw(dhw < 4) = 0;

prob_dhw_4 = zeros(length(lat),1);

days = 1:length(t(1,:));

for i = 1:length(lat)
    [~,locs] = findpeaks(dhw(i,:),days,'MinPeakDistance',60);
    stress_years = t(:,locs);
    stress_years = unique(stress_years(1,:));
    prob_dhw_4(i,:) = length(stress_years)/length(all_years);
end

prob_dhw_4 = round(prob_dhw_4,2);
prob_dhw_4(idx_nan,:) = NaN;

%+------------------------------------------------------------------------+
%| Calculate oberved probability of bleaching > 8DHW for 1985-2019.       |
%+------------------------------------------------------------------------+

dhw(dhw < 8) = 0;

prob_dhw_8 = zeros(length(lat),1);

for i = 1:length(lat)
    [~,locs] = findpeaks(dhw(i,:),days,'MinPeakDistance',60);
    stress_years = t(:,locs);
    stress_years = unique(stress_years(1,:));
    prob_dhw_8(i,:) = length(stress_years)/length(all_years);
end

prob_dhw_8 = round(prob_dhw_8,2);
prob_dhw_8(idx_nan,:) = NaN;

%+------------------------------------------------------------------------+
%| Write probability of DHW > 4DHW to file.                               |
%+------------------------------------------------------------------------+

filepath = 'observed/prob_dhw_4_japan.csv';

data = [id lon lat prob_dhw_4];

csvwrite(filepath,data)

filepath = 'observed/prob_dhw_8_japan.csv';

data = [id lon lat prob_dhw_8];

csvwrite(filepath,data)


quit;
