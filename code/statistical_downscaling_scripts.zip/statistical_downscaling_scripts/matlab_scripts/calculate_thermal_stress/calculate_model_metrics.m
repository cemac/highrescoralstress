%+------------------------------------------------------------------------+
%| Matlab script to calculate projected degree heating weeks (DHW) and    | 
%| thermal stress metrics.                                                |
%| Adele Dixon - last updated 01/06/2022                                  |
%+------------------------------------------------------------------------+

%+------------------------------------------------------------------------+
%| Set model names.                                                       |
%+------------------------------------------------------------------------+

model = {'ACCESS-CM2','ACCESS-ESM1-5','BCC-CSM2-MR','CanESM5','CESM2-WACCM',...
    'CMCC-CM2-SR5','EC-Earth3','EC-Earth3-Veg','GFDL-CM4','IPSL-CM6A-LR',...
    'MPI-ESM1-2-HR','MRI-ESM2-0','NESM3','NorESM2-LM','NorESM2-MM'};

r = str2double(getenv('SGE_TASK_ID'));

%+------------------------------------------------------------------------+
%| Set SSP names.                                                         |
%+------------------------------------------------------------------------+

if r == 9
    ssp = {'ssp245','ssp585'};
elseif r == 13
    ssp = {'ssp126','ssp245','ssp585'};
else
    ssp = {'ssp126','ssp245','ssp370','ssp585'};
end

for ssp_no = 1:length(ssp)

%+------------------------------------------------------------------------+
%| Read in downscaled SST.                                                |
%+------------------------------------------------------------------------+

filepath = strcat(model{r},'/',ssp{ssp_no},...
    '/downscaled_sst_japan_1985_2100.nc');

id = ncread(filepath,'id');
lat = ncread(filepath,'lat');
lon = ncread(filepath,'lon');
t = ncread(filepath,'time');
sst = ncread(filepath,'sst');

idx_nan = isnan(sst(:,1));

%+------------------------------------------------------------------------+
%| Convert days since 01/01/1985 to year, month, day.                     |
%+------------------------------------------------------------------------+

pivotyr = '1985-01-01';
t_datenum = t + datenum(pivotyr);
t = datevec(t_datenum);

t = datetime(t,'InputFormat','yyyy-MM-dd');

[y,m,d] = ymd(t);
t = [y m d];
t = t';

%+------------------------------------------------------------------------+
%| Calculate annual mean SST.                                             |
%+------------------------------------------------------------------------+

[~,~,y_idx] = unique(t(1,:)','rows','stable');
y_idx = y_idx';

ann_mn = zeros(length(lat),max(y_idx));
for i = 1:max(y_idx)
    ann_mn(:,i) = mean(sst(:,(y_idx==i)),2);
end

%+------------------------------------------------------------------------+
%| Find trend and p-value for feasible generalised least squares for each |
%| 20-year time period.                                                   |
%+------------------------------------------------------------------------+

start_years = [2021 2041 2061 2081];
end_years = [2040 2060 2080 2100];

yr = unique(t(1,:));

fgls_slope = zeros(length(lat),length(start_years));
fgls_p = zeros(length(lat),length(start_years));

for j = 1:length(start_years)
    idx = yr >= start_years(j) & yr <= end_years(j);
    all_years = yr(:,idx);
    n = length(all_years) - 2;
    for i = 1:length(lat)
        % Find slope and p-value for generalised least squares
        if isnan(ann_mn(i,1))
            fgls_slope(i,j) = NaN;
            fgls_p(i,j) = NaN;
        else
            [coeff,se] = fgls(all_years',ann_mn(i,idx)','arLags',1);
            fgls_slope(i,j) = coeff(2);
            t2 = coeff(2)/se(2);
            fgls_p(i,j) = 2*tcdf(-abs(t2),n);
        end
        disp(i)
    end
end

%+------------------------------------------------------------------------+
%| Write trend in annual mean sst.                                        |
%+------------------------------------------------------------------------+

filepath = strcat(model{r},'/',ssp{ssp_no},...
    '/trend_ann_mn_sst_japan.csv');

data = [id lon lat fgls_slope fgls_p];

csvwrite(filepath,data)

%+------------------------------------------------------------------------+
%| Calculate degree heating weeks (DHW). Method by NOAA Coral Reef Watch  |
%| https://coralreefwatch.noaa.gov/product/5km/methodology.php#dhw        |
%+------------------------------------------------------------------------+
%+------------------------------------------------------------------------+
%| Calculate monthly mean SST.                                            |
%+------------------------------------------------------------------------+

[my,~,my_idx] = unique(t(1:2,:)','rows','stable');
my_idx = my_idx';

month_mn = zeros(length(lat),max(my_idx));
for i = 1:max(my_idx)
    month_mn(:,i) = mean(sst(:,(my_idx==i)),2);
end

%+------------------------------------------------------------------------+
%| Find maximum monthly mean (MMM) period (1985-2012).                    |
%+------------------------------------------------------------------------+
    
mmm_idx = my(:,1) >= 1985 & my(:,1) <= 2012;
m_idx = my(mmm_idx,2);

mmm_idx = mmm_idx';
month_mn_base = month_mn(:,mmm_idx);

yr = 1985:2012;

%+------------------------------------------------------------------------+
%| Regress monthly mean (MM) 1985-2012.                                   |
%+------------------------------------------------------------------------+

mm = zeros(length(lat),max(m_idx));

for i = 1:length(lat)
    for k = 1:max(m_idx)
        p = polyfit(yr,month_mn_base(i,m_idx==k),1);
        mm(i,k) = p(1)*1988.2857 + p(2);
    end
end

%+------------------------------------------------------------------------+
%| Find MMM.                                                              |
%+------------------------------------------------------------------------+

mmm = max(mm,[],2);

%+------------------------------------------------------------------------+
%| Calculate hotspots.                                                    |
%+------------------------------------------------------------------------+

sst_anom = sst - mmm;

clearvars sst

%+------------------------------------------------------------------------+
%| Calculate DHWs (> 1 degC).                                             |
%+------------------------------------------------------------------------+

sst_anom(sst_anom < 1) = 0;

d = t(3,84:end);
d_idx = 1:length(d);

dhw = zeros(length(lat),length(d));
for i = 1:length(lat)
    k = 84;
    for j = 1:max(d_idx)
         dhw(i,j) = sum(sst_anom(i,k-83:k)/7);
         k = k+1;
    end
end

clearvars sst_anom

%+------------------------------------------------------------------------+
%| Calculate projected probability of bleaching > 4DHW for 20-year        |
%| periods: 2021-2040, 2041-2060, 2061-2080, 2081-2100.                   |
%+------------------------------------------------------------------------+

t = t(:,84:end);

dhw(dhw < 4) = 0;

prob_dhw_4 = zeros(length(lat),length(start_years));

for j = 1:length(start_years)
    idx = t(1,:) >= start_years(j) & t(1,:) <= end_years(j);
    t_years = t(:,idx);
    all_years = unique(t_years(1,:));
for i = 1:length(lat)
    days = 1:length(dhw(i,idx));
    [~,locs] = findpeaks(dhw(i,idx),days,'MinPeakDistance',60);
    stress_years = t_years(1,locs);
    stress_years = unique(stress_years);
    prob_dhw_4(i,j) = length(stress_years)/length(all_years);
end
end

prob_dhw_4(idx_nan,:) = NaN;

%+------------------------------------------------------------------------+
%| Calculate projected probability of bleaching > 8DHW for 20-year        |
%| periods: 2021-2040, 2041-2060, 2061-2080, 2081-2100.                   |
%+------------------------------------------------------------------------+

dhw(dhw < 8) = 0;

prob_dhw_8 = zeros(length(lat),length(start_years));

for j = 1:length(start_years)
    idx = t(1,:) >= start_years(j) & t(1,:) <= end_years(j);
    t_years = t(:,idx);
    all_years = unique(t_years(1,:));
for i = 1:length(lat)
    days = 1:length(dhw(i,idx));
    [~,locs] = findpeaks(dhw(i,idx),days,'MinPeakDistance',60);
    stress_years = t_years(1,locs);
    stress_years = unique(stress_years);
    prob_dhw_8(i,j) = length(stress_years)/length(all_years);
end
end

prob_dhw_8(idx_nan,:) = NaN;

%+------------------------------------------------------------------------+
%| Write probability of DHW > 4DHW to file.                               |
%+------------------------------------------------------------------------+

filepath = strcat(model{r},'/',ssp{ssp_no},...
    '/prob_dhw_4_japan.csv');

data = [id lon lat prob_dhw_4];

csvwrite(filepath,data)

filepath = strcat(model{r},'/',ssp{ssp_no},...
    '/prob_dhw_8_japan.csv');

data = [id lon lat prob_dhw_8];

csvwrite(filepath,data)


end

quit;
