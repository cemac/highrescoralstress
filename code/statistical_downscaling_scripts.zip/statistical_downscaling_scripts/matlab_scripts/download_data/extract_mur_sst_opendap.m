%+------------------------------------------------------------------------+
%| Matlab script to extract MUR SST data using OPeNDAP.                   |
%| Adele Dixon - last updated 01/12/2021                                  |
%+------------------------------------------------------------------------+

%+------------------------------------------------------------------------+
%| Set time period.                                                       |
%+------------------------------------------------------------------------+

t1 = datetime(2003,01,01);
t2 = datetime(2019,12,31);
t = t1:t2;

%+------------------------------------------------------------------------+
%| Set filenames by adding a zero in front of single digit days and       |
%| months.                                                                |
%+------------------------------------------------------------------------+

[y,m,d] = ymd(t);

% DAYS

d_string = cell(length(t),1);
for i = 1:length(t)
   if d(i) < 10
       d_string{i} = strcat(num2str(0),num2str(d(i)));
   else
       d_string{i} = num2str(d(i));
   end
end

% MONTHS

m_string = cell(length(t),1);
for i = 1:length(t)
   if m(i) < 10
       m_string{i} = strcat(num2str(0),num2str(m(i)));
   else
       m_string{i} = num2str(m(i));
   end
end

%+------------------------------------------------------------------------+
%| Set day number.                                                        |
%+------------------------------------------------------------------------+

y_u = unique(y);

day_no = cell(length(y_u),1);
for i = 1:length(y_u)
    idx = find(y == y_u(i));
    day_no{i} = 1:length(idx); 
    day_no{i} = day_no{i}';
end

day_no = cell2mat(day_no);

%+------------------------------------------------------------------------+
%| Add zeros in front of single/double digit day numbers.                 |
%+------------------------------------------------------------------------+

day_no_string = cell(length(t),1);
for i = 1:length(t)
   if day_no(i) < 10
       day_no_string{i} = strcat('00',num2str(day_no(i)));
   elseif day_no(i) >= 10 && day_no(i) < 100
       day_no_string{i} = strcat('0',num2str(day_no(i)));
   else
       day_no_string{i} = num2str(day_no(i));
   end
end

%+------------------------------------------------------------------------+
%| Extract latitude and longitude.                                        |
%+------------------------------------------------------------------------+

i = 1;
url_grid = strcat('https://podaac-opendap.jpl.nasa.gov/opendap/',...
        'allData/ghrsst/data/GDS2/L4/GLOB/JPL/MUR/v4.1/',num2str(y(i)),...
        '/',day_no_string{i},'/',num2str(y(i)),m_string{i},d_string{i},...
        '090000-JPL-L4_GHRSST-SSTfnd-MUR-GLOB-v02.0-fv04.1.nc');

lat = ncread(url_grid,'lat');
lon = ncread(url_grid,'lon');

%+------------------------------------------------------------------------+
%| Read in coordinates to extract data for.                               |
%+------------------------------------------------------------------------+

coords = csvread('observed/japan/xy_coords_japan.csv');

%+------------------------------------------------------------------------+
%| Find the range of MUR data to download.                                |
%+------------------------------------------------------------------------+

min_lat = min(coords(:,2));
max_lat = max(coords(:,2));
min_lon = min(coords(:,3));
max_lon = max(coords(:,3));

idx = find(lat > (min_lat-0.05) & lat < (max_lat+0.05));
lat = lat(idx);
start_lat = min(idx);
range_lat = length(idx);

idx = find(lon > (min_lon-0.05) & lon < (max_lon+0.05));
lon = lon(idx);
start_lon = min(idx);
range_lon = length(idx);

%+------------------------------------------------------------------------+
%| Find the index number of the coordinates to download.                  |
%+------------------------------------------------------------------------+

lat = double(lat);
lon = double(lon);

lat = round(lat,2);
lon = round(lon,2);
coords(:,2:3) = round(coords(:,2:3),2);

lat_idx = zeros(length(coords(:,1)),1);
lon_idx = zeros(length(coords(:,1)),1);

for j = 1:length(coords(:,1))
    lat_idx(j) = find(lat == coords(j,2));
    lon_idx(j) = find(lon == coords(j,3));
end

%+------------------------------------------------------------------------+
%| Extract SST for coordinates.                                           |
%+------------------------------------------------------------------------+

sst_mursst = zeros(length(coords(:,1)),length(t));

for i = 1:length(t)
    url_grid = strcat('https://podaac-opendap.jpl.nasa.gov/opendap/',...
        'allData/ghrsst/data/GDS2/L4/GLOB/JPL/MUR/v4.1/',num2str(y(i)),...
        '/',day_no_string{i},'/',num2str(y(i)),m_string{i},d_string{i},...
        '090000-JPL-L4_GHRSST-SSTfnd-MUR-GLOB-v02.0-fv04.1.nc');
    sst = ncread(url_grid,'analysed_sst',[start_lon start_lat 1],...
        [range_lon range_lat inf],[1 1 1]);
    for j = 1:length(coords(:,1))
        sst_reef = sst(lon_idx(j),lat_idx(j));
        if isnan(sst_reef)
            sst_reef = sst(lon_idx(j)+1,lat_idx(j));
        else
        end
        if isnan(sst_reef)
            sst_reef = sst(lon_idx(j)-1,lat_idx(j));
        else
        end
        if isnan(sst_reef)
            sst_reef = sst(lon_idx(j),lat_idx(j)+1);
        else
        end
        if isnan(sst_reef)
            sst_reef = sst(lon_idx(j),lat_idx(j)-1);
        else
        end
        if isnan(sst_reef)
            sst_reef = sst(lon_idx(j)+1,lat_idx(j)+1);
        else
        end
        if isnan(sst_reef)
            sst_reef = sst(lon_idx(j)+1,lat_idx(j)-1);
        else
        end
        if isnan(sst_reef)
            sst_reef = sst(lon_idx(j)-1,lat_idx(j)-1);
        else
        end
        if isnan(sst_reef)
            sst_reef = sst(lon_idx(j)-1,lat_idx(j)+1);
        else
        end
        sst_mursst(j,i) = sst_reef;
    end
    disp(i)
end

%+------------------------------------------------------------------------+
%| Convert SST from Kelvin to degrees Celsius.                            |
%+------------------------------------------------------------------------+

sst_mursst = sst_mursst - 273.15;

%+------------------------------------------------------------------------+
%| Write SST data to file.                                                |
%+------------------------------------------------------------------------+

t = 1:length(t);

data = [coords sst_mursst];
t = [nan(1,3) t];
data = [t;data];

csvwrite('observed/japan/sst_mur_japan.csv',data)

