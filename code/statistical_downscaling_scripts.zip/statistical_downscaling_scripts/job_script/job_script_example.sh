# Set current working directory
#$ -cwd
# Export current environment  
#$ -V
# Set time allocation (2 min limit)
#$ -l h_rt=06:00:00
#Request more memory, the default is 1Gb
#$ -l h_vmem=10G
#$ -t 1-15
#Email at the beginning and end of the job
#$ -m be
#$ -M username@leeds.ac.uk
# Load matlab module
module add matlab
# run matlab using command file
# -nodisplay flag should be given to suppress graphics
matlab -nodisplay < matlab_script.m
